"""SS OIL PC <-> Supabase event bridge, standard library only.
Does not edit or import the PC server or its SQLite file.
Requires a compatible /shared GET+POST endpoint and token.
"""
import json, os, sqlite3, time, uuid, urllib.request, urllib.parse, urllib.error, logging, datetime, hashlib, sys
from decimal import Decimal, InvalidOperation
from pathlib import Path

BASE=os.environ.get('SSOIL_PC_URL','http://127.0.0.1:8767').rstrip('/')
TOKEN=os.environ.get('SSOIL_PC_TOKEN','')
SUPA=os.environ.get('SSOIL_SUPABASE_URL','').rstrip('/')
KEY=os.environ.get('SSOIL_SERVICE_ROLE_KEY','')
DB=(Path(sys.executable).resolve().parent if getattr(sys,'frozen',False) else Path(__file__).resolve().parent)/'kopru_durum.sqlite3'
SECTIONS={'labels','orders','suppliers','supplierOf','minimum','discrepancies','orderUnits','barcodeErrors','photos'}
logging.basicConfig(level=logging.INFO,format='%(asctime)s %(levelname)s %(message)s')

def req(url, method='GET', payload=None, headers=None):
    body=None if payload is None else json.dumps(payload,ensure_ascii=False).encode('utf-8')
    request=urllib.request.Request(url,data=body,method=method,headers=headers or {})
    try:
        with urllib.request.urlopen(request,timeout=8) as r:
            data=r.read()
            return json.loads(data) if data else None
    except urllib.error.HTTPError as exc:
        raw=exc.read().decode('utf-8',errors='replace')
        # Never log headers, credentials, or arbitrary response data.
        try:
            err=json.loads(raw)
            detail=str(err.get('message') or err.get('error_description') or err.get('error') or err.get('code') or '')
        except Exception:
            detail='(sunucu ayrintili JSON hata mesaji vermedi)'
        safe_path=urllib.parse.urlsplit(url).path
        raise RuntimeError(f'HTTP {exc.code} [{method} {safe_path}]: {detail[:300]}') from None

def pc(path,method='GET',payload=None):
    return req(BASE+path,method,payload,{'X-SSOIL-Token':TOKEN,'Content-Type':'application/json'})

def cloud(path,method='GET',payload=None):
    return req(SUPA+'/rest/v1/'+path,method,payload,{
        'apikey':KEY,'Authorization':'Bearer '+KEY,'Content-Type':'application/json',
        'Prefer':'resolution=merge-duplicates,return=minimal'})

def getstate(db,key):
    row=db.execute('select v from state where k=?',(key,)).fetchone()
    return int(row[0]) if row else 0

def setstate(db,key,value):
    db.execute('insert into state(k,v) values(?,?) on conflict(k) do update set v=excluded.v',(key,str(value)))

def canonical(value):
    return json.dumps(value,sort_keys=True,ensure_ascii=False,separators=(',',':'),default=str)

FIELDS=('cash','cash_smpsz','cash_fuel','cash_market','fuel_sales','market_sales','card','mtel_dopuna','aero_dopuna','refund')

def money(v):
    if isinstance(v,bool) or v is None: raise ValueError('missing numeric amount')
    try:
        d=Decimal(str(v))
        if not d.is_finite(): raise ValueError('nonfinite')
        return d.quantize(Decimal('0.01'))
    except (InvalidOperation,ValueError,TypeError): raise ValueError('invalid numeric amount')

def checked_kasa(value,kind):
    if not isinstance(value,dict): raise ValueError('Kasa response not an object')
    for field in ('date',)+FIELDS:
        if field not in value or value[field] is None:
            raise ValueError('%s: missing %s'%(kind,field))
    for field in FIELDS: money(value[field])
    if not value.get('cash_complete') or not value.get('cash_split_verified'):
        raise ValueError('%s: unverified PC cash or split'%kind)
    # These equalities are mandatory; a nonempty/verified row alone is NOT enough.
    if abs(money(value['cash_fuel'])+money(value['cash_market'])-money(value['cash_smpsz']))>Decimal('0.01'):
        raise ValueError('%s: INVALID CASH SPLIT: cash_fuel + cash_market != cash_smpsz'%kind)
    if abs(money(value['cash_smpsz'])+money(value['mtel_dopuna'])+money(value['aero_dopuna'])-money(value['cash']))>Decimal('0.01'):
        raise ValueError('%s: INVALID CASH TOTAL incl dopuna'%kind)
    if kind.startswith('kasa:') and value['date']!=kind[5:]:
        raise ValueError('%s: PC returned wrong date'%kind)
    dop=value.get('dopuna') or {}
    for source in ('mtel','aero'):
        obj=dop.get(source) or {}
        if obj.get('status')!='ok' or money(obj.get('total'))!=money(value[source+'_dopuna']):
            raise ValueError('%s: %s dopuna not verified'%(kind,source))
    return value

def publish_snapshot(kind, path, db=None):
    value=pc(path)
    if not isinstance(value,dict): raise RuntimeError('PC response is not an object: '+kind)
    if kind=='kasa' or kind.startswith('kasa:'): checked_kasa(value,kind)
    query='ssoil_snapshots?select=kind,data&kind=eq.'+urllib.parse.quote(kind,safe='')+'&limit=1'
    remote=cloud(query) or []
    previous=remote[0]['data'] if remote else None
    if previous is not None and kind.startswith('kasa'):
        differences=[]
        for field in FIELDS:
            try:
                if money(previous.get(field))!=money(value.get(field)):
                    differences.append('%s:%s->%s'%(field,previous.get(field),value.get(field)))
            except ValueError: differences.append('%s:missing/invalid'%field)
        if differences: logging.info('Kasa updated %s: %s',kind,', '.join(differences))
    if previous is not None and canonical(previous)==canonical(value): return value
    cloud('ssoil_snapshots?on_conflict=kind','POST',[{'kind':kind,'data':value}])
    # Read back from Supabase: never assume the POST was stored correctly.
    confirmed=cloud(query) or []
    if not confirmed or canonical(confirmed[0].get('data'))!=canonical(value):
        # Never declare success on a failed read-back. Diagnose which fields differ.
        got=confirmed[0].get('data') if confirmed else None
        if kind=='kasa' or kind.startswith('kasa:'):
            actual=got if isinstance(got,dict) else {}
            diff=[f for f in FIELDS if (f not in actual or money(actual[f])!=money(value[f]))]
            extra=[f for f in set(value)|set(actual) if f not in FIELDS and canonical(value.get(f))!=canonical(actual.get(f))]
            raise RuntimeError('Supabase read-back differs: %s; amounts=%s; other=%s'%(kind,','.join(diff) or 'none',','.join(sorted(extra))[:200] or 'none'))
        raise RuntimeError('Supabase read-back differs: '+kind)
    logging.info('Supabase read-back verified: %s',kind)
    return value

def snapshots(db):
    for kind,path in [('products','/snapshot'),('sales','/sales'),('daily-sales','/daily-sales')]:
        try: publish_snapshot(kind,path,db)
        except Exception as exc: logging.warning('Snapshot %s: %s',kind,exc)
    today=datetime.date.today()
    day=today.isoformat()
    for kind,path in [('kasa','/kasa?date='+day),('kasa:'+day,'/kasa?date='+day),('shared-state','/shared-state')]:
        try: publish_snapshot(kind,path,db)
        except Exception as exc: logging.warning('Snapshot %s: %s',kind,exc)
    start_str=os.environ.get('SSOIL_HISTORY_START','2026-08-31')
    start=datetime.date.fromisoformat(start_str)
    if start>=today:return
    days=(today-start).days
    # Continuous rolling audit: each historical day is re-compared eventually.
    # No permanent completed cursor; errors cannot block other days.
    offset=getstate(db,'audit_offset')%days
    batch=max(1,int(os.environ.get('SSOIL_AUDIT_DAYS_PER_CYCLE','10')))
    for i in range(min(batch,days)):
        day=(start+datetime.timedelta(days=(offset+i)%days)).isoformat()
        try: publish_snapshot('kasa:'+day,'/kasa?date='+day,db)
        except Exception as exc: logging.warning('History audit %s: %s',day,exc)
    setstate(db,'audit_offset',(offset+batch)%days)
    db.commit()


def sync_events(db):
    """Poll the actual pending queue, not a monotonically increasing cloud_id.

    Rows can arrive late or be retried with older IDs; every visible row is
    considered. A failed row must never stop other rows or Kasa refresh.
    """
    events=cloud('ssoil_events?select=id,event_id,section,item_key,value&order=id.asc&limit=200') or []
    applied=[]
    for event in events:
        eid=event.get('event_id')
        sec=event.get('section')
        event_id=event.get('id')
        try:
            if isinstance(eid,str) and eid.startswith('pc-') and eid[3:].isdigit():
                # Old bridge echo; not a phone command.
                applied.append(event_id)
                continue
            if sec not in SECTIONS:
                raise ValueError('unsupported section')
            key=str(event.get('item_key') or '')
            if not key or len(key)>200 or not isinstance(eid,str) or not (8<=len(eid)<=200):
                raise ValueError('invalid event key or ID')
            # PC /shared must be idempotent on event_id; never invent a new ID.
            result=pc('/shared','POST',{'section':sec,'key':key,'value':event.get('value'),'event_id':eid})
            if not isinstance(result,dict) or 'revision' not in result:
                raise RuntimeError('PC did not confirm the operation')
            applied.append(event_id)
        except Exception as exc:
            logging.warning('Event %s not confirmed; retained for retry: %s',event_id,exc)
            continue
    if not applied:
        return
    # Acknowledgment by canonical snapshot, *before* deleting messages.
    # If publish fails, keep messages. PC idempotency makes retries safe.
    try:
        publish_snapshot('shared-state','/shared-state',db)
    except Exception as exc:
        logging.warning('Cannot publish shared-state; events retained: %s',exc)
        return
    for event_id in applied:
        try:
            cloud('ssoil_events?id=eq.'+str(int(event_id)),'DELETE')
        except Exception as exc:
            logging.warning('Cannot clean confirmed event %s: %s',event_id,exc)


def sync(db):
    # Independent stages: a failed event cannot prevent stock/Kasa refresh.
    try:
        sync_events(db)
    except Exception as exc:
        logging.error('Event queue poll failed; other snapshots continue: %s',exc)
    try:
        snapshots(db)
    except Exception as exc:
        logging.error('Snapshot cycle failed; event polling resumes next cycle: %s',exc)


def main():
    if not all([TOKEN,SUPA,KEY]):
        raise SystemExit('Missing SSOIL_PC_TOKEN / SSOIL_SUPABASE_URL / SSOIL_SERVICE_ROLE_KEY')
    if not SUPA.startswith('https://'):
        raise SystemExit('Supabase URL must be HTTPS')
    with sqlite3.connect(DB) as db:
        db.execute('create table if not exists state(k text primary key,v text not null)')
        db.execute('create table if not exists skip_revision(rev integer primary key)')
        db.execute('create table if not exists snapshot_hash(kind text primary key,digest text not null)')
        db.commit()
        while True:
            try: sync(db)
            except Exception as exc: logging.error('Sync failed (will retry): %s',exc)
            time.sleep(3)

if __name__=='__main__': main()
