"""SS OIL vardiya: same 8767 HTTP server, same SQLite, no source SQL writes.
Cloud credentials are read from environment; never embedded in source.
"""
import json, uuid, datetime, urllib.parse, urllib.request, urllib.error, os, threading, time, sqlite3
TABLES={
 'ssoil_shift_options':('id',), 'ssoil_shift_banks':('id',),
 'ssoil_shift_employees':('id',),'ssoil_shift_transactions':('id',),
 'ssoil_shift_daily':('business_date',),
 'ssoil_shift_bank_opening':('business_date','bank_id'),
 'ssoil_shift_handoffs':('id',)
}
URL=os.getenv('SSOIL_SUPABASE_URL','').rstrip('/')
KEY=os.getenv('SSOIL_SERVICE_ROLE_KEY','')

def init(conn):
 with conn() as c:
  c.execute('CREATE TABLE IF NOT EXISTS vardiya_local(table_name TEXT NOT NULL,row_key TEXT NOT NULL,payload TEXT NOT NULL,pending INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(table_name,row_key))')
  c.execute('CREATE TABLE IF NOT EXISTS vardiya_outbox(event_id TEXT PRIMARY KEY,table_name TEXT NOT NULL,row_key TEXT NOT NULL,operation TEXT NOT NULL,payload TEXT NOT NULL,created_at TEXT DEFAULT CURRENT_TIMESTAMP,error TEXT)')
  c.execute('CREATE TABLE IF NOT EXISTS vardiya_status(id INTEGER PRIMARY KEY CHECK(id=1),last_sync TEXT,error TEXT)')

def row_key(t,row):return '|'.join(str(row[x]) for x in TABLES[t])

def select(rows,qs):
 for field,values in qs.items():
  if field in ('select','limit','offset','order','on_conflict'):continue
  for value in values:
   if value.startswith('eq.'):
    wanted=value[3:];rows=[r for r in rows if str(r.get(field,''))==wanted]
   elif value=='is.null':rows=[r for r in rows if r.get(field) is None]
 order=qs.get('order',[''])[0]
 if order:
  parts=order.split('.');field=parts[0];desc='desc' in parts[1:]
  rows.sort(key=lambda r:(r.get(field) is None,str(r.get(field) or '')),reverse=desc)
 return rows[int(qs.get('offset',['0'])[0]):][:min(10000,int(qs.get('limit',['10000'])[0]))]

def handle(api,path,qs,conn,lock):
 if not path.startswith('/vardiya/'):return False
 t=path[len('/vardiya/'):]
 if t not in TABLES:return api.respond(404,{'error':'unknown_vardiya_table'})
 if api.command not in ('GET','POST','PATCH'):return api.respond(405,{'error':'method_not_allowed'})
 try:
  with lock,conn() as c:
   rows=[json.loads(x[0]) for x in c.execute('SELECT payload FROM vardiya_local WHERE table_name=?',(t,)).fetchall()]
   matching=select(rows,qs)
   if api.command=='GET':return api.respond(200,matching)
   size=int(api.headers.get('Content-Length','0'))
   if size>100000:return api.respond(413,{'error':'too_large'})
   data=json.loads(api.rfile.read(size))
   if api.command=='POST':
    items=data if isinstance(data,list) else [data]
    if not items or len(items)>100:return api.respond(400,{'error':'invalid_items'})
    result=[]
    for item in items:
     if not isinstance(item,dict):return api.respond(400,{'error':'invalid_row'})
     item=dict(item)
     if 'id' in TABLES[t]:item.setdefault('id',str(uuid.uuid4()))
     if any(not item.get(col) for col in TABLES[t]):return api.respond(400,{'error':'missing_primary_key'})
     k=row_key(t,item)
     if c.execute('SELECT 1 FROM vardiya_local WHERE table_name=? AND row_key=?',(t,k)).fetchone():return api.respond(409,{'error':'duplicate_row'})
     result.append((k,item))
    for k,item in result:
     raw=json.dumps(item,ensure_ascii=False)
     c.execute('INSERT INTO vardiya_local(table_name,row_key,payload,pending) VALUES(?,?,?,1)',(t,k,raw))
     c.execute('INSERT INTO vardiya_outbox(event_id,table_name,row_key,operation,payload) VALUES(?,?,?,?,?)',(str(uuid.uuid4()),t,k,'POST',raw))
    return api.respond(201,[item for _,item in result])
   if not isinstance(data,dict):return api.respond(400,{'error':'invalid_patch'})
   if not matching:return api.respond(200,[])
   result=[]
   for old in matching:
    k=row_key(t,old)
    if any(col in data and str(data[col])!=str(old[col]) for col in TABLES[t]):return api.respond(400,{'error':'primary_key_immutable'})
    if c.execute('SELECT 1 FROM vardiya_local WHERE table_name=? AND row_key=? AND pending=1',(t,k)).fetchone():return api.respond(409,{'error':'previous_change_pending'})
    new=dict(old);new.update(data)
    if 'revision' in old:new['revision']=int(old.get('revision') or 0)+1
    result.append((k,old,new))
   for k,old,new in result:
    c.execute('UPDATE vardiya_local SET payload=?,pending=1 WHERE table_name=? AND row_key=?',(json.dumps(new,ensure_ascii=False),t,k))
    patch=dict(data)
    # Use old revision as optimistic concurrency precondition on cloud.
    if 'revision' in old:patch['_expected_revision']=old.get('revision',0)
    c.execute('INSERT INTO vardiya_outbox(event_id,table_name,row_key,operation,payload) VALUES(?,?,?,?,?)',(str(uuid.uuid4()),t,k,'PATCH',json.dumps(patch,ensure_ascii=False)))
   return api.respond(200,[new for _,_,new in result])
 except (ValueError,KeyError,TypeError,json.JSONDecodeError) as e:return api.respond(400,{'error':str(e)[:180]})
 except sqlite3.Error:return api.respond(500,{'error':'vardiya_database_error'})

def cloud(t,method='GET',body=None,params='',prefer='return=representation'):
 if not URL or not KEY:raise RuntimeError('Supabase env eksik')
 url=URL+'/rest/v1/'+t+('?' +params if params else '')
 headers={'apikey':KEY,'Authorization':'Bearer '+KEY,'Content-Type':'application/json','Prefer':prefer}
 req=urllib.request.Request(url,method=method,headers=headers,data=json.dumps(body,ensure_ascii=False).encode() if body is not None else None)
 with urllib.request.urlopen(req,timeout=10) as r:
  b=r.read();return json.loads(b) if b else []

def sync_once(conn,lock):
 # Push before pull, preserving locally queued changes.
 with conn() as c:jobs=c.execute('SELECT event_id,table_name,row_key,operation,payload FROM vardiya_outbox ORDER BY created_at LIMIT 50').fetchall()
 for event,t,k,op,raw in jobs:
  try:
   data=json.loads(raw)
   cols=TABLES[t];vals=k.split('|')
   params='&'.join(urllib.parse.quote(col)+'=eq.'+urllib.parse.quote(val,safe='') for col,val in zip(cols,vals))
   if op=='POST':
    response=cloud(t,'POST',[data]);
    if not response:raise RuntimeError('empty POST result')
   else:
    expected=data.pop('_expected_revision',None)
    if expected is not None:params+='&revision=eq.'+str(expected)
    response=cloud(t,'PATCH',data,params)
    if len(response)!=1:raise RuntimeError('revision conflict; change kept locally for review')
   with lock,conn() as c:
    c.execute('DELETE FROM vardiya_outbox WHERE event_id=?',(event,))
    pending=c.execute('SELECT 1 FROM vardiya_outbox WHERE table_name=? AND row_key=?',(t,k)).fetchone()
    if not pending:
     c.execute('UPDATE vardiya_local SET payload=?,pending=0 WHERE table_name=? AND row_key=?',(json.dumps(response[0],ensure_ascii=False),t,k))
  except Exception as e:
   with conn() as c:c.execute('UPDATE vardiya_outbox SET error=? WHERE event_id=?',(str(e)[:200],event))
 for t in TABLES:
  remote=[];offset=0
  while True:
   batch=cloud(t,params='select=*&limit=500&offset='+str(offset))
   remote.extend(batch)
   if len(batch)<500:break
   offset+=500
   if offset>100000:raise RuntimeError('row limit')
  with lock,conn() as c:
   for row in remote:
    k=row_key(t,row)
    c.execute('INSERT INTO vardiya_local(table_name,row_key,payload,pending) VALUES(?,?,?,0) ON CONFLICT(table_name,row_key) DO UPDATE SET payload=excluded.payload WHERE vardiya_local.pending=0',(t,k,json.dumps(row,ensure_ascii=False)))
   remote_keys={row_key(t,row) for row in remote}
   for (k,) in c.execute('SELECT row_key FROM vardiya_local WHERE table_name=? AND pending=0',(t,)).fetchall():
    if k not in remote_keys:c.execute('DELETE FROM vardiya_local WHERE table_name=? AND row_key=?',(t,k))
 with conn() as c:c.execute("INSERT INTO vardiya_status(id,last_sync,error) VALUES(1,datetime('now'),NULL) ON CONFLICT(id) DO UPDATE SET last_sync=excluded.last_sync,error=NULL")

def loop(conn,lock):
 last_ok=0
 while True:
  try:
   sync_once(conn,lock)
   if time.monotonic()-last_ok>300:
    print('[VARDIYA SYNC] OK',flush=True)
    last_ok=time.monotonic()
  except Exception as e:
   print('[VARDIYA SYNC]',str(e)[:200],flush=True)
   with conn() as c:c.execute('INSERT INTO vardiya_status(id,error) VALUES(1,?) ON CONFLICT(id) DO UPDATE SET error=excluded.error',(str(e)[:200],))
  time.sleep(3)
