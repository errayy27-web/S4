"""Single Windows process: existing PC 8767 + existing bridge + Vardiya."""
import os,threading,time,traceback
import merkez

def run_bridge():
 try:
  import kopru
  kopru.main()
 except BaseException as e:
  print('[KOPRU]',str(e),flush=True)

if __name__=='__main__':
 merkez.setup()
 import vardiya_entegre
 vardiya_entegre.init(merkez.conn)
 threading.Thread(target=merkez.poll_loop,daemon=True,name='SQL_SELECT').start()
 threading.Thread(target=vardiya_entegre.loop,args=(merkez.conn,merkez.LOCK),daemon=True,name='VARDIYA_SYNC').start()
 if all(os.environ.get(x) for x in ('SSOIL_PC_TOKEN','SSOIL_SUPABASE_URL','SSOIL_SERVICE_ROLE_KEY')):
  threading.Thread(target=run_bridge,daemon=True,name='SUPABASE_KOPRU').start()
 else:
  print('Supabase kopru env eksik; yerel 8767 devam ediyor.',flush=True)
 from http.server import ThreadingHTTPServer
 host=merkez.CFG.get('listen','127.0.0.1');port=int(merkez.CFG.get('port',8767))
 print('SS OIL tek EXE | PC 8767 + Vardiya |',host,port,flush=True)
 ThreadingHTTPServer((host,port),merkez.API).serve_forever()
