"""SS OIL 8767 auxiliary archival layer. Never writes to external sources."""
import sqlite3, datetime, hashlib, json, math

TABLES = {
 'MERKEZ_ART':'CREATE TABLE IF NOT EXISTS MERKEZ_ART (_key TEXT PRIMARY KEY, _data TEXT NOT NULL, _updated TEXT NOT NULL)',
 'MERKEZ_SMP_S':'CREATE TABLE IF NOT EXISTS MERKEZ_SMP_S (_key TEXT PRIMARY KEY, Broj TEXT, Tarih TEXT, _data TEXT NOT NULL, _seen TEXT NOT NULL)',
 'MERKEZ_SMP_Z':'CREATE TABLE IF NOT EXISTS MERKEZ_SMP_Z (_key TEXT PRIMARY KEY, Broj TEXT, Tarih TEXT, _data TEXT NOT NULL, _seen TEXT NOT NULL)',
 'MERKEZ_KAHVE':'CREATE TABLE IF NOT EXISTS MERKEZ_KAHVE (id INTEGER PRIMARY KEY AUTOINCREMENT, tarih TEXT, tutar REAL, veri TEXT)',
 'MERKEZ_MTEL_DOPUNA':'CREATE TABLE IF NOT EXISTS MERKEZ_MTEL_DOPUNA (islem_id TEXT PRIMARY KEY, tarih TEXT, tutar REAL, veri TEXT)',
 'MERKEZ_AERO_DOPUNA':'CREATE TABLE IF NOT EXISTS MERKEZ_AERO_DOPUNA (islem_id TEXT PRIMARY KEY, tarih TEXT, tutar REAL, veri TEXT)',
 'UYG_MTEL_GUNLUK':'CREATE TABLE IF NOT EXISTS UYG_MTEL_GUNLUK (tarih TEXT PRIMARY KEY, toplam_tutar REAL NOT NULL, islem_sayisi INTEGER NOT NULL, updated_at TEXT DEFAULT CURRENT_TIMESTAMP)',
 'UYG_AERO_GUNLUK':'CREATE TABLE IF NOT EXISTS UYG_AERO_GUNLUK (tarih TEXT PRIMARY KEY, toplam_tutar REAL NOT NULL, islem_sayisi INTEGER NOT NULL, updated_at TEXT DEFAULT CURRENT_TIMESTAMP)',
 'MERKEZ_ETIKET_EKSIK':'CREATE TABLE IF NOT EXISTS MERKEZ_ETIKET_EKSIK (id TEXT PRIMARY KEY, barkod TEXT, fiyat REAL, updated_at TEXT DEFAULT CURRENT_TIMESTAMP)',
 'MERKEZ_SIPARIS_LISTESI':'CREATE TABLE IF NOT EXISTS MERKEZ_SIPARIS_LISTESI (kayit_id INTEGER PRIMARY KEY AUTOINCREMENT, id TEXT, barkod TEXT, isim TEXT, miktar REAL, tedarikci TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP)',
 'MERKEZ_STOK_SAYIM':'CREATE TABLE IF NOT EXISTS MERKEZ_STOK_SAYIM (kayit_id INTEGER PRIMARY KEY AUTOINCREMENT, id TEXT, isim TEXT, barkod TEXT, gorunen_stok REAL, reel_stok REAL, eksik REAL, fazla REAL, created_at TEXT DEFAULT CURRENT_TIMESTAMP)',
 'MERKEZ_URUN_FOTOGRAFLARI':'CREATE TABLE IF NOT EXISTS MERKEZ_URUN_FOTOGRAFLARI (id TEXT PRIMARY KEY, resim BLOB, updated_at TEXT DEFAULT CURRENT_TIMESTAMP)',
 'MERKEZ_URUN_TEDARIKCI':'CREATE TABLE IF NOT EXISTS MERKEZ_URUN_TEDARIKCI (id TEXT PRIMARY KEY, barkod TEXT, tedarikci TEXT, tur TEXT)',
 'MERKEZ_MUSTERI_KART_HAREKETLERI':'CREATE TABLE IF NOT EXISTS MERKEZ_MUSTERI_KART_HAREKETLERI (hareket_id INTEGER PRIMARY KEY AUTOINCREMENT, musteri_id TEXT, tarih TEXT, alisveris_tutari REAL, alisveris_turu TEXT CHECK(alisveris_turu IN (\'YAKIT\',\'MARKET\')))',
 'MERKEZ_ARSIV_DURUM':'CREATE TABLE IF NOT EXISTS MERKEZ_ARSIV_DURUM (kaynak TEXT PRIMARY KEY, durum TEXT, detay TEXT, updated_at TEXT DEFAULT CURRENT_TIMESTAMP)',
 'TELEFON_URUNLER':'CREATE TABLE IF NOT EXISTS TELEFON_URUNLER (id TEXT PRIMARY KEY, name TEXT, price REAL, stock REAL, barcodes TEXT NOT NULL DEFAULT NULL, updated_at TEXT DEFAULT CURRENT_TIMESTAMP)',
 'UYG_ART_HESAP':'CREATE TABLE IF NOT EXISTS UYG_ART_HESAP (id TEXT PRIMARY KEY, isim TEXT, barkodlar TEXT, fiyat REAL, kaynak_stok REAL, satis_miktari REAL, net_stok REAL, updated_at TEXT DEFAULT CURRENT_TIMESTAMP)'
}

def initialize(c):
 for ddl in TABLES.values():c.execute(ddl)
 c.execute('CREATE INDEX IF NOT EXISTS idx_merkez_smp_s_broj ON MERKEZ_SMP_S(Broj)')
 c.execute('CREATE INDEX IF NOT EXISTS idx_merkez_smp_z_broj ON MERKEZ_SMP_Z(Broj)')

def normalize(v):
 if isinstance(v,(bytes,bytearray,memoryview)):return {'hex':bytes(v).hex()}
 if isinstance(v,(datetime.datetime,datetime.date)):return v.isoformat()
 if isinstance(v,float) and not math.isfinite(v):return None
 return v

def fetch_all(sql_read,table):
 # Explicitly read only. Fetch column names from SQL cursor description.
 import pyodbc
 # caller provides connection string separately; do not alter configuration.
 raise NotImplementedError

def sql_rows(cfg,table):
 import pyodbc
 with pyodbc.connect(cfg['odbc_connection'],timeout=8,autocommit=True) as remote:
  cur=remote.cursor();cur.execute('SELECT * FROM dbo.'+table)
  cols=[d[0] for d in cur.description]
  for chunk in iter(lambda:cur.fetchmany(500),[]):
   for r in chunk:yield dict(zip(cols,(normalize(v) for v in r)))

def hash_row(row):
 return hashlib.sha256(json.dumps(row,ensure_ascii=False,sort_keys=True,default=str).encode()).hexdigest()

def update_dopuna_totals(c):
 # Every day is one row. Do not delete historic days or recompute on phone.
 for archive,daily in [('MERKEZ_MTEL_DOPUNA','UYG_MTEL_GUNLUK'),('MERKEZ_AERO_DOPUNA','UYG_AERO_GUNLUK')]:
  for day,total,count in c.execute('SELECT tarih,ROUND(SUM(tutar),2),COUNT(*) FROM '+archive+' GROUP BY tarih').fetchall():
   c.execute('INSERT INTO '+daily+'(tarih,toplam_tutar,islem_sayisi) VALUES(?,?,?) ON CONFLICT(tarih) DO UPDATE SET toplam_tutar=excluded.toplam_tutar,islem_sayisi=excluded.islem_sayisi,updated_at=CURRENT_TIMESTAMP',(day,total,count))

def update_derived(c):
 # Backfill legacy transaction records into the new central archives.
 for source,archive in [('mtel','MERKEZ_MTEL_DOPUNA'),('aero','MERKEZ_AERO_DOPUNA')]:
  for r in c.execute('SELECT source_id,tx_date,tx_time,amount_minor,status_id,client_tx,server_tx FROM dopuna_transactions WHERE source=?',(source,)).fetchall():
   data={'id':r[0],'date':r[2],'amount':r[3],'statusId':r[4],'clientTx':r[5],'serverTx':r[6]}
   c.execute('INSERT OR IGNORE INTO '+archive+'(islem_id,tarih,tutar,veri) VALUES(?,?,?,?)',(r[0],r[1],int(r[3])/100,json.dumps(data,ensure_ascii=False)))
 update_dopuna_totals(c)
 # Phone products are MATERIALIZED, never calculated at HTTP request time.
 # Today's confirmed archived receipt lines are summed per product; older dates retained but not subtracted.
 today=datetime.date.today().isoformat()
 sold={}
 for raw,day in c.execute('SELECT _data,Tarih FROM MERKEZ_SMP_S WHERE Tarih IS NOT NULL'):
  try:
   r=json.loads(raw)
   date=str(day)[:10]
   if date!=today:
    try:date=datetime.datetime.fromisoformat(str(day)).date().isoformat()
    except ValueError:continue
   if date!=today:continue
   pid=str(r.get('Art_ID',''))
   qty=float(r.get('Kolicina') or 0)
   if pid and math.isfinite(qty):sold[pid]=sold.get(pid,0)+qty
  except (ValueError,TypeError,KeyError):continue
 for pid,raw in c.execute('SELECT _key,_data FROM MERKEZ_ART').fetchall():
  try:
   r=json.loads(raw);stock=float(r.get('Kolicina') or 0);price=float(r.get('PCena') or 0)
   net=stock-sold.get(pid,0)
   name=str(r.get('Naziv') or '')
   barcode=c.execute('SELECT barcodes FROM products_snapshot WHERE product_id=?',(pid,)).fetchone()
   barcodes=barcode[0] if barcode else '[]'
   c.execute('INSERT INTO TELEFON_URUNLER(id,name,price,stock,barcodes) VALUES(?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name,price=excluded.price,stock=excluded.stock,barcodes=excluded.barcodes,updated_at=CURRENT_TIMESTAMP',(pid,name,price,net,barcodes))
   c.execute('INSERT INTO UYG_ART_HESAP(id,isim,barkodlar,fiyat,kaynak_stok,satis_miktari,net_stok) VALUES(?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET isim=excluded.isim,barkodlar=excluded.barkodlar,fiyat=excluded.fiyat,kaynak_stok=excluded.kaynak_stok,satis_miktari=excluded.satis_miktari,net_stok=excluded.net_stok,updated_at=CURRENT_TIMESTAMP',(pid,name,barcodes,price,stock,sold.get(pid,0),net))
  except (ValueError,TypeError):continue



def _columns(cursor, table):
    cursor.execute('SELECT TOP 0 * FROM dbo.' + table)
    return {d[0].lower(): d[0] for d in cursor.description}


def _day(raw):
    if isinstance(raw, datetime.datetime): return raw.date().isoformat()
    if isinstance(raw, datetime.date): return raw.isoformat()
    value=str(raw or '').strip()
    if not value: raise ValueError('Tarih bos')
    for fmt in ('%Y-%m-%d %H:%M:%S.%f','%Y-%m-%d %H:%M:%S','%Y-%m-%d', '%d.%m.%Y %H:%M:%S','%d.%m.%Y'):
        try:return datetime.datetime.strptime(value,fmt).date().isoformat()
        except ValueError:pass
    return datetime.datetime.fromisoformat(value).date().isoformat()


def _number(v):
    x=float(v or 0)
    if not math.isfinite(x):raise ValueError('Gecersiz tutar')
    return x


def _is_reklamacija(v):
    # Existing production SmP_Z logic identifies reklamacija with '*' exactly.
    # Reject other nonblank values until semantics have been verified.
    s=str(v or '').strip()
    if s and s != '*':
        raise RuntimeError('Bilinmeyen Reklamacija degeri: '+repr(s))
    return s=='*'


def import_history_once(db_connect,cfg):
    """One-off, all-or-nothing historical import. Source is strictly SELECT only."""
    import pyodbc
    with db_connect() as local:
        initialize(local)
        local.execute('CREATE TABLE IF NOT EXISTS history_import_state (source TEXT PRIMARY KEY, completed_at TEXT, z_count INTEGER, s_count INTEGER)')
        if local.execute("SELECT 1 FROM history_import_state WHERE source='Pr_Z_Pr_S'").fetchone():
            return 'Gecmis satislar zaten aktarilmis; yeniden okunmadi.'
    with pyodbc.connect(cfg['odbc_connection'],timeout=20,autocommit=True) as remote:
        cur=remote.cursor()
        zcols=_columns(cur,'Pr_Z'); scols=_columns(cur,'Pr_S')
        needed_z={'broj','datume','reklamacija','gotovina','povracaj','kartica'}
        needed_s={'broj','art_id','kolicina'}
        if not needed_z.issubset(zcols) or not needed_s.issubset(scols):
            raise RuntimeError('Pr_Z veya Pr_S beklenen alanlari eksik. Pr_Z: '+str(sorted(needed_z-set(zcols)))+'; Pr_S: '+str(sorted(needed_s-set(scols))))
        # A receipt ID alone must be unambiguous; otherwise do not assign sales to wrong days.
        # Kasa_ID is part of identity if present in both tables.
        key_fields=['broj']+(['kasa_id'] if 'kasa_id' in zcols and 'kasa_id' in scols else [])
        if ('kasa_id' in zcols) != ('kasa_id' in scols):
            raise RuntimeError('Kasa_ID sadece bir tabloda var; guvenli eslestirme yapilamadi')
        today=datetime.date.today().isoformat()
        zrecords={}; cash={}; n_z=0
        cur.execute('SELECT * FROM dbo.Pr_Z')
        zfields=[d[0] for d in cur.description]
        while True:
            batch=cur.fetchmany(1000)
            if not batch:break
            for values in batch:
                r=dict(zip(zfields,values)); day=_day(r[zcols['datume']])
                if day>=today:continue
                key=tuple(str(r[zcols[f]]) for f in key_fields)
                if key in zrecords:
                    raise RuntimeError('Pr_Z icinde ayni fis kimligi tekrar ediyor: '+str(key)+'; aktarim durduruldu')
                valid=not _is_reklamacija(r[zcols['reklamacija']])
                zrecords[key]=(day,valid,r)
                if valid:
                    totals=cash.setdefault(day,[0.,0.,0.,0.,0.])
                    for i,field in enumerate(('gotovina','povracaj','kartica','bonus','regres')):
                        if field in zcols:totals[i]+=_number(r[zcols[field]])
                n_z+=1
        # Read all historical sales, but only count lines with a unique valid Z.
        lines=[]; daily={}; n_s=0; unmatched=0
        cur.execute('SELECT * FROM dbo.Pr_S')
        sfields=[d[0] for d in cur.description]
        while True:
            batch=cur.fetchmany(1000)
            if not batch:break
            for values in batch:
                r=dict(zip(sfields,values)); key=tuple(str(r[scols[f]]) for f in key_fields)
                match=zrecords.get(key)
                if match is None:
                    unmatched+=1;continue
                day,valid,_=match
                if not valid:continue
                pid=str(r[scols['art_id']]); qty=_number(r[scols['kolicina']])
                daily[(day,pid)]=daily.get((day,pid),0.)+qty
                lines.append((day,str(r[scols['broj']]),r))
                n_s+=1
        if unmatched:
            raise RuntimeError(str(unmatched)+' Pr_S satiri Pr_Z ile eslesmedi; eksik satis yazmamak icin aktarim durduruldu')
        # Write everything in one SQLite transaction. No partial history on failure.
        with db_connect() as local:
            initialize(local)
            local.execute('CREATE TABLE IF NOT EXISTS history_import_state (source TEXT PRIMARY KEY, completed_at TEXT, z_count INTEGER, s_count INTEGER)')
            if local.execute("SELECT 1 FROM history_import_state WHERE source='Pr_Z_Pr_S'").fetchone():
                return 'Gecmis satislar zaten aktarilmis.'
            for key,(day,valid,r) in zrecords.items():
                if not valid:continue
                raw=json.dumps(r,ensure_ascii=False,default=str)
                local.execute('INSERT OR IGNORE INTO MERKEZ_SMP_Z(_key,Broj,Tarih,_data,_seen) VALUES(?,?,?,?,CURRENT_TIMESTAMP)',('PRZ:'+hash_row({'key':key}),str(r[zcols['broj']]),day,raw))
            for i,(day,broj,r) in enumerate(lines):
                local.execute('INSERT OR IGNORE INTO MERKEZ_SMP_S(_key,Broj,Tarih,_data,_seen) VALUES(?,?,?,?,CURRENT_TIMESTAMP)',('PRS:'+str(i),broj,day,json.dumps(r,ensure_ascii=False,default=str)))
            for day,v in cash.items():
                local.execute('INSERT INTO cash_daily(day,gotovina,povracaj,kartica,bonus,regres) VALUES(?,?,?,?,?,?) ON CONFLICT(day) DO UPDATE SET gotovina=excluded.gotovina,povracaj=excluded.povracaj,kartica=excluded.kartica,bonus=excluded.bonus,regres=excluded.regres,updated_at=CURRENT_TIMESTAMP',(day,*v))
            for (day,pid),qty in daily.items():
                local.execute('INSERT INTO sales_daily(day,product_id,quantity) VALUES(?,?,?) ON CONFLICT(day,product_id) DO UPDATE SET quantity=excluded.quantity',(day,pid,qty))
            local.execute("INSERT INTO history_import_state(source,completed_at,z_count,s_count) VALUES('Pr_Z_Pr_S',CURRENT_TIMESTAMP,?,?)",(n_z,n_s))
    return f'Gecmis aktarim tamamlandi: {n_z} Z, {n_s} gecerli S satiri, {len(cash)} gun.'


def run(db_connect,cfg):
    # This is called every few seconds: never rescan historical SQL.
    with db_connect() as c:
        initialize(c)
        c.execute('CREATE TABLE IF NOT EXISTS history_import_state (source TEXT PRIMARY KEY, completed_at TEXT, z_count INTEGER, s_count INTEGER)')
        done=c.execute("SELECT 1 FROM history_import_state WHERE source='Pr_Z_Pr_S'").fetchone()
    if not done:
        try:
            message=import_history_once(db_connect,cfg)
            with db_connect() as c:
                c.execute('INSERT INTO MERKEZ_ARSIV_DURUM(kaynak,durum,detay) VALUES(?,?,?) ON CONFLICT(kaynak) DO UPDATE SET durum=excluded.durum,detay=excluded.detay,updated_at=CURRENT_TIMESTAMP',('SQL_GECMIS','TAMAM',message))
        except Exception as exc:
            with db_connect() as c:
                c.execute('INSERT INTO MERKEZ_ARSIV_DURUM(kaynak,durum,detay) VALUES(?,?,?) ON CONFLICT(kaynak) DO UPDATE SET durum=excluded.durum,detay=excluded.detay,updated_at=CURRENT_TIMESTAMP',('SQL_GECMIS','HATA',str(exc)[:350]))
    # One-time local-only group derivation; never rescan old SQL.
    try:
        with db_connect() as c:
            c.execute('CREATE TABLE IF NOT EXISTS ssoil_tasks_done(name TEXT PRIMARY KEY)')
            group_done=c.execute("SELECT 1 FROM ssoil_tasks_done WHERE name='history_groups'").fetchone()
        if not group_done:
            import ssoil_kasa_ek
            ssoil_kasa_ek.backfill_groups_from_local(db_connect,cfg)
            with db_connect() as c:c.execute("INSERT OR IGNORE INTO ssoil_tasks_done(name) VALUES('history_groups')")
    except Exception as exc:
        with db_connect() as c:
            c.execute('INSERT INTO MERKEZ_ARSIV_DURUM(kaynak,durum,detay) VALUES(?,?,?) ON CONFLICT(kaynak) DO UPDATE SET durum=excluded.durum,detay=excluded.detay,updated_at=CURRENT_TIMESTAMP',('KASA_GRUP_ARSIV','HATA',str(exc)[:350]))
    # Re-audit all historical receipt amounts, even if cached and marked verified.
    try:
        import ssoil_kasa_ek
        ssoil_kasa_ek.repair_historical_groups_from_receipts(db_connect,cfg)
    except Exception as exc:
        with db_connect() as c:
            c.execute('INSERT INTO MERKEZ_ARSIV_DURUM(kaynak,durum,detay) VALUES(?,?,?) ON CONFLICT(kaynak) DO UPDATE SET durum=excluded.durum,detay=excluded.detay,updated_at=CURRENT_TIMESTAMP',('KASA_TEK_TEK_KONTROL','HATA',str(exc)[:350]))
    # Recheck from 00:00 until Pr_Z, Pr_S and verified fuel/market split are archived.
    now=datetime.datetime.now()
    with db_connect() as c:
        c.execute('CREATE TABLE IF NOT EXISTS ssoil_closed_days(day TEXT PRIMARY KEY,closed_at TEXT DEFAULT CURRENT_TIMESTAMP)')
        # Reopen closed days whose fuel/market split was not persisted or verified.
        c.execute('''DELETE FROM ssoil_closed_days WHERE day IN
          (SELECT d.day FROM ssoil_closed_days d LEFT JOIN kasa_group_daily g ON g.day=d.day
           WHERE d.day<? AND (g.day IS NULL OR g.verified<>1 OR g.fuel_sales IS NULL OR g.market_sales IS NULL))''',
          (now.date().isoformat(),))
        last=c.execute('SELECT MAX(day) FROM ssoil_closed_days').fetchone()[0]
        if last is None:
            # Never infer a completed day from cash-only history.
            last=None
    target=now.date()-datetime.timedelta(days=1)
    cursor=(datetime.date.fromisoformat(last)+datetime.timedelta(days=1)) if last else target
    if cursor>target:return
    import ssoil_kasa_ek
    try:
        ssoil_kasa_ek.close_day(db_connect,cfg,cursor.isoformat())
        with db_connect() as c:
            c.execute('INSERT INTO MERKEZ_ARSIV_DURUM(kaynak,durum,detay) VALUES(?,?,?) ON CONFLICT(kaynak) DO UPDATE SET durum=excluded.durum,detay=excluded.detay,updated_at=CURRENT_TIMESTAMP',('SQL_GUN_KAPANIS','TAMAM','Pr_Z ve Pr_S arsivlendi: '+cursor.isoformat()))
    except Exception as exc:
        with db_connect() as c:
            c.execute('INSERT INTO MERKEZ_ARSIV_DURUM(kaynak,durum,detay) VALUES(?,?,?) ON CONFLICT(kaynak) DO UPDATE SET durum=excluded.durum,detay=excluded.detay,updated_at=CURRENT_TIMESTAMP',('SQL_GUN_KAPANIS','HATA',str(exc)[:350]))
