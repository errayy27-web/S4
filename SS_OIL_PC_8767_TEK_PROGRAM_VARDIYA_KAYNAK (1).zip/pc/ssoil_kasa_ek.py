'''Only new Kasa/archive calculations. Source SQL is SELECT-only.'''
import datetime, json, math, sqlite3

FUEL_DEFAULT=('1','2','3')

def fuel_ids(cfg):
    value=cfg.get('fuel_art_ids',['1','2','3'])
    if isinstance(value,dict):
        values=[x for group in value.values() for x in group]
        if not values:values=list(FUEL_DEFAULT)
    elif isinstance(value,str): values=value.split(',')
    else: values=value
    return {str(x).strip() for x in values}

def day_bounds(day):
    d=datetime.date.fromisoformat(day)
    return day,(d+datetime.timedelta(days=1)).isoformat()

def get_columns(cur,table):
    cur.execute('SELECT TOP 0 * FROM dbo.'+table)
    return {d[0].lower():d[0] for d in cur.description}

def good_reklamacija(value):
    marker=str(value or '').strip()
    if marker not in ('','*'):
        raise ValueError('Bilinmeyen Reklamacija degeri: '+repr(marker))
    return marker!='*'

def calc_groups(db_connect, cfg, day, live=False):
    """Split actual line Iznos by Art_ID. Exclude reklamacija and validate receipts."""
    import pyodbc
    ztable='SmP_Z' if live else 'Pr_Z'
    stable='SmP_S' if live else 'Pr_S'
    a,b=day_bounds(day)
    with pyodbc.connect(cfg['odbc_connection'],timeout=12,autocommit=True) as remote:
        cur=remote.cursor()
        zcols=get_columns(cur,ztable); scols=get_columns(cur,stable)
        mandatory_z={'broj','datume','reklamacija','gotovina','povracaj','kartica'}
        mandatory_s={'broj','art_id','iznos'}
        if not mandatory_z.issubset(zcols) or not mandatory_s.issubset(scols):
            raise ValueError('Pr_Z/Pr_S gerekli kolonlari eksik')
        keys=['broj']+[k for k in ('kasa_id','smena_id') if k in zcols and k in scols]
        cur.execute('SELECT * FROM dbo.'+ztable+' WHERE '+zcols['datume']+'>=? AND '+zcols['datume']+'<?',(a,b))
        zn=[d[0] for d in cur.description]
        receipts={}
        for values in cur:
            r=dict(zip(zn,values)); key=tuple(str(r[zcols[k]]) for k in keys)
            if key in receipts:raise ValueError('Tekrarlanan fis kimligi: '+repr(key))
            if not good_reklamacija(r[zcols['reklamacija']]):continue
            receipts[key]={'z':r,'fuel':0.,'market':0.,'count':0}
        if not receipts:
            return {'fuel_sales':0.,'market_sales':0.,'cash_fuel':0.,'cash_market':0.,'split_verified':True,'sales_verified':True,'excluded_reklamacija':True}
        join=' AND '.join('z.'+zcols[k]+'=s.'+scols[k] for k in keys)
        cur.execute('SELECT s.* FROM dbo.'+stable+' s WHERE EXISTS (SELECT 1 FROM dbo.'+ztable+' z WHERE '+join+' AND z.'+zcols['datume']+'>=? AND z.'+zcols['datume']+'<?)',(a,b))
        sn=[d[0] for d in cur.description]
        fuel=fuel_ids(cfg)
        for values in cur:
            r=dict(zip(sn,values));key=tuple(str(r[scols[k]]) for k in keys)
            if key not in receipts:continue
            amount=float(r[scols['iznos']] or 0)
            if not math.isfinite(amount):raise ValueError('Gecersiz Pr_S Iznos')
            category='fuel' if str(r[scols['art_id']]).strip() in fuel else 'market'
            receipts[key][category]+=amount
            receipts[key]['count']+=1
        fuel_sales=market_sales=cash_fuel=cash_market=0.
        for key,info in receipts.items():
            if not info['count']:raise ValueError('Pr_S eksik fis: '+repr(key))
            z=info['z']; f=info['fuel'];m=info['market'];line_total=f+m
            if line_total<=0:raise ValueError('Gecersiz fis satir toplami: '+repr(key))
            # Source Pr_Z Iznos is the authoritative sale total. Reject discrepancies.
            if 'iznos' in zcols:
                ztotal=float(z[zcols['iznos']] or 0)
                if abs(ztotal-line_total)>max(0.05,abs(ztotal)*0.002):
                    raise ValueError('Pr_Z / Pr_S toplam farki: '+repr(key))
            cash=float(z[zcols['gotovina']] or 0)-float(z[zcols['povracaj']] or 0)
            fuel_sales+=f;market_sales+=m
            cash_fuel+=cash*f/line_total
            cash_market+=cash*m/line_total
        return {'fuel_sales':round(fuel_sales,2),'market_sales':round(market_sales,2),
                'cash_fuel':round(cash_fuel,2),'cash_market':round(cash_market,2),
                'split_verified':True,'sales_verified':True,
                'excluded_reklamacija':True,'receipt_count':len(receipts)}

def group_cache_setup(c):
    c.execute('''CREATE TABLE IF NOT EXISTS kasa_group_daily(
        day TEXT PRIMARY KEY, fuel_sales REAL, market_sales REAL,
        cash_fuel REAL,cash_market REAL, verified INTEGER NOT NULL,
        detail TEXT NOT NULL DEFAULT '', updated_at TEXT DEFAULT CURRENT_TIMESTAMP)''')

def save_group(db_connect,day,data):
    with db_connect() as c:
        group_cache_setup(c)
        c.execute('''INSERT INTO kasa_group_daily(day,fuel_sales,market_sales,cash_fuel,cash_market,verified,detail)
            VALUES(?,?,?,?,?,?,?) ON CONFLICT(day) DO UPDATE SET
            fuel_sales=excluded.fuel_sales,market_sales=excluded.market_sales,
            cash_fuel=excluded.cash_fuel,cash_market=excluded.cash_market,
            verified=excluded.verified,detail=excluded.detail,updated_at=CURRENT_TIMESTAMP''',
            (day,data.get('fuel_sales'),data.get('market_sales'),data.get('cash_fuel'),data.get('cash_market'),
             int(data.get('split_verified',False)),json.dumps(data,ensure_ascii=False)))

def get_group(db_connect,day):
    with db_connect() as c:
        group_cache_setup(c)
        row=c.execute('SELECT * FROM kasa_group_daily WHERE day=?',(day,)).fetchone()
    return dict(row) if row else None

def close_day(db_connect,cfg,day):
    '''Retry previous day from 00:00 until detail and group totals are archived.'''
    import pyodbc
    import merkez_arsiv
    with db_connect() as c:
        c.execute('''CREATE TABLE IF NOT EXISTS ssoil_closed_days(day TEXT PRIMARY KEY,closed_at TEXT DEFAULT CURRENT_TIMESTAMP)''')
        if c.execute('SELECT 1 FROM ssoil_closed_days WHERE day=?',(day,)).fetchone():return False
    # Pr_Z must have rows; do not seal a missing day.
    a,b=day_bounds(day)
    with pyodbc.connect(cfg['odbc_connection'],timeout=12,autocommit=True) as r:
        cur=r.cursor();cur.execute('SELECT COUNT(*) FROM dbo.Pr_Z WHERE DatumE>=? AND DatumE<?',(a,b))
        if int(cur.fetchone()[0])==0:raise RuntimeError('Pr_Z gunluk Z henuz hazir degil: '+day)
    # Reuse the safe one-off importer for the initial history; after that only
    # one closed day is materialized in daily cash/group tables.
    groups=calc_groups(db_connect,cfg,day,False)
    # Capture the actual daily Pr_Z / Pr_S rows, not just payment totals.
    # Source SQL remains SELECT-only. The local write is atomic with day closing.
    with pyodbc.connect(cfg['odbc_connection'],timeout=20,autocommit=True) as remote:
        cur=remote.cursor()
        zcols=get_columns(cur,'Pr_Z'); scols=get_columns(cur,'Pr_S')
        if ('kasa_id' in zcols) != ('kasa_id' in scols):
            raise RuntimeError('Pr_Z/Pr_S Kasa_ID uyumsuz')
        keys=['broj']+[k for k in ('kasa_id','smena_id') if k in zcols and k in scols]
        cur.execute('SELECT * FROM dbo.Pr_Z WHERE '+zcols['datume']+'>=? AND '+zcols['datume']+'<?',(a,b))
        zn=[x[0] for x in cur.description]
        zrows=[dict(zip(zn,r)) for r in cur.fetchall()]
        if not zrows:raise RuntimeError('Pr_Z bos: '+day)
        identities=set()
        for r in zrows:
            key=tuple(str(r[zcols[k]]) for k in keys)
            if key in identities:raise RuntimeError('Pr_Z tekrarlanan fis: '+str(key))
            identities.add(key)
            good_reklamacija(r[zcols['reklamacija']])
        join=' AND '.join('z.'+zcols[k]+'=s.'+scols[k] for k in keys)
        cur.execute('SELECT s.* FROM dbo.Pr_S s WHERE EXISTS (SELECT 1 FROM dbo.Pr_Z z WHERE '+join+' AND z.'+zcols['datume']+'>=? AND z.'+zcols['datume']+'<?)',(a,b))
        sn=[x[0] for x in cur.description]
        srows=[dict(zip(sn,r)) for r in cur.fetchall()]
        # Never mark a day complete when its item rows have not arrived yet.
        if not srows:raise RuntimeError('Pr_S gunluk satirlar henuz yok: '+day)
        for r in srows:
            if tuple(str(r[scols[k]]) for k in keys) not in identities:
                raise RuntimeError('Pr_S eslesmeyen fis: '+day)
    # Mixed receipts retain unknown group splits; closing totals remain authoritative.
    # Never block closing forever merely because a split cannot be verified.
    with pyodbc.connect(cfg['odbc_connection'],timeout=12,autocommit=True) as r:
        cur=r.cursor();cur.execute('''SELECT COALESCE(SUM(CAST(Gotovina AS float)),0),
          COALESCE(SUM(CAST(Povracaj AS float)),0),COALESCE(SUM(CAST(Kartica AS float)),0),
          COALESCE(SUM(CAST(Bonus AS float)),0),COALESCE(SUM(CAST(Regres AS float)),0)
          FROM dbo.Pr_Z WHERE DatumE>=? AND DatumE<? AND
          (Reklamacija IS NULL OR LTRIM(RTRIM(CAST(Reklamacija AS NVARCHAR(100))))='')''',(a,b))
        amounts=tuple(float(x or 0) for x in cur.fetchone())
    with db_connect() as c:
        group_cache_setup(c)
        c.execute('''CREATE TABLE IF NOT EXISTS ssoil_closed_days(day TEXT PRIMARY KEY,closed_at TEXT DEFAULT CURRENT_TIMESTAMP)''')
        c.execute('INSERT INTO cash_daily(day,gotovina,povracaj,kartica,bonus,regres) VALUES(?,?,?,?,?,?) ON CONFLICT(day) DO UPDATE SET gotovina=excluded.gotovina,povracaj=excluded.povracaj,kartica=excluded.kartica,bonus=excluded.bonus,regres=excluded.regres,updated_at=CURRENT_TIMESTAMP',(day,*amounts))
        c.execute('''INSERT INTO kasa_group_daily(day,fuel_sales,market_sales,cash_fuel,cash_market,verified,detail)
            VALUES(?,?,?,?,?,?,?) ON CONFLICT(day) DO UPDATE SET
            fuel_sales=excluded.fuel_sales,market_sales=excluded.market_sales,cash_fuel=excluded.cash_fuel,
            cash_market=excluded.cash_market,verified=excluded.verified,detail=excluded.detail''',
            (day,groups['fuel_sales'],groups['market_sales'],groups['cash_fuel'],groups['cash_market'],int(groups['split_verified']),json.dumps(groups)))
        import hashlib
        # Distinct line occurrences are preserved even if two rows are identical.
        # All inserts are in the same transaction as cash_daily and closed_days.
        for r in zrows:
            key=tuple(str(r[zcols[k]]) for k in keys)
            identity=json.dumps([day,key],ensure_ascii=False)
            h=hashlib.sha256(identity.encode()).hexdigest()
            c.execute('INSERT OR IGNORE INTO MERKEZ_SMP_Z(_key,Broj,Tarih,_data,_seen) VALUES(?,?,?,?,CURRENT_TIMESTAMP)',
                      ('PRZ:'+h,str(r[zcols['broj']]),day,json.dumps(r,ensure_ascii=False,default=str)))
        for idx,r in enumerate(srows):
            key=json.dumps([day,idx,r],ensure_ascii=False,sort_keys=True,default=str)
            h=hashlib.sha256(key.encode()).hexdigest()
            c.execute('INSERT OR IGNORE INTO MERKEZ_SMP_S(_key,Broj,Tarih,_data,_seen) VALUES(?,?,?,?,CURRENT_TIMESTAMP)',
                      ('PRSD:'+h,str(r[scols['broj']]),day,json.dumps(r,ensure_ascii=False,default=str)))
        c.execute('INSERT OR IGNORE INTO ssoil_closed_days(day) VALUES(?)',(day,))
    return True

def backfill_groups_from_local(db_connect,cfg):
    """Build historical group snapshots from already-imported SQLite, no source SQL reads."""
    with db_connect() as c:
        group_cache_setup(c)
        zrows=c.execute("SELECT Tarih,_data FROM MERKEZ_SMP_Z WHERE _key LIKE 'PRZ:%'").fetchall()
        srows=c.execute("SELECT Tarih,_data FROM MERKEZ_SMP_S WHERE _key LIKE 'PRS:%'").fetchall()
        existing={r[0] for r in c.execute('SELECT day FROM kasa_group_daily')}
        receipts={}; by_broj={}
        for day,raw in zrows:
            if day in existing:continue
            z=json.loads(raw);key=(day,str(z.get('Broj')),str(z.get('Kasa_ID','')))
            if key in receipts:
                receipts[key]['ambiguous']=True
            else:receipts[key]={'z':z,'ids':set(),'ambiguous':False}
            by_broj.setdefault((day,str(z.get('Broj'))),set()).add(key)
        for day,raw in srows:
            if day in existing:continue
            r=json.loads(raw); keys=by_broj.get((day,str(r.get('Broj'))),set())
            if 'Kasa_ID' in r:keys={key for key in keys if key[2]==str(r.get('Kasa_ID'))}
            if len(keys)==1:receipts[next(iter(keys))]['ids'].add(str(r.get('Art_ID')))
            else:
                for key in keys:receipts[key]['ambiguous']=True
        fuel=fuel_ids(cfg);by_day={}
        for (day,_,_),entry in receipts.items():
            d=by_day.setdefault(day,{'fuel_sales':0.,'market_sales':0.,'cash_fuel':0.,'cash_market':0.,'split_verified':True,'mixed_receipts':0,'unmatched_receipts':0})
            ids=entry['ids'];z=entry['z']
            if entry['ambiguous'] or not ids:
                d['split_verified']=False;d['unmatched_receipts']+=1;continue
            if ids & fuel and ids-fuel:
                d['split_verified']=False;d['mixed_receipts']+=1;continue
            try:
                cash=float(z.get('Gotovina') or 0)-float(z.get('Povracaj') or 0)
                amount=cash+float(z.get('Kartica') or 0)
            except (ValueError,TypeError):d['split_verified']=False;continue
            category='fuel' if ids & fuel else 'market'
            d[category+'_sales']+=amount
            d['cash_'+category]+=cash
        for day,d in by_day.items():
            if not d['split_verified']:
                for k in ('fuel_sales','market_sales','cash_fuel','cash_market'):d[k]=None
            else:
                for k in ('fuel_sales','market_sales','cash_fuel','cash_market'):d[k]=round(d[k],2)
            c.execute('INSERT OR IGNORE INTO kasa_group_daily(day,fuel_sales,market_sales,cash_fuel,cash_market,verified,detail) VALUES(?,?,?,?,?,?,?)',
                (day,d['fuel_sales'],d['market_sales'],d['cash_fuel'],d['cash_market'],int(d['split_verified']),json.dumps(d)))


def repair_historical_groups_from_receipts(db_connect, cfg):
    # Recompute archived dates from individual validated Pr_Z/Pr_S receipts.
    # Existing verified flags are ignored. Source SQL is never written.
    from collections import defaultdict
    with db_connect() as c:
        group_cache_setup(c)
        receipts = defaultdict(dict)
        for day, raw in c.execute("SELECT Tarih,_data FROM MERKEZ_SMP_Z WHERE _key LIKE 'PRZ:%'"):
            z = json.loads(raw)
            key = tuple(str(z.get(k, '')) for k in ('Broj','Kasa_ID','Smena_ID'))
            if key in receipts[day]:
                raise ValueError('Duplicate archived receipt: %s %s' % (day,key))
            receipts[day][key] = [z, [], False]
        for day, raw in c.execute("SELECT Tarih,_data FROM MERKEZ_SMP_S WHERE _key LIKE 'PRS:%' OR _key LIKE 'PRSD:%'"):
            if day not in receipts: continue
            s = json.loads(raw)
            key = tuple(str(s.get(k, '')) for k in ('Broj','Kasa_ID','Smena_ID'))
            if key in receipts[day]:
                # PRSD is an additional archive of the same transaction; de-duplicate
                # by the actual source line identity (RB) and contents.
                receipts[day][key][1].append(s)
        fuel = fuel_ids(cfg)
        changed = 0
        for day, group in sorted(receipts.items()):
            sums = {'fuel_sales':0.,'market_sales':0.,'cash_fuel':0.,'cash_market':0.}
            bad = []
            net_cash = 0.
            for key, (z, raw_lines, _) in group.items():
                if not good_reklamacija(z.get('Reklamacija')): continue
                # Prefer original PRS archive over PRSD if both exist.
                lines = {}
                for s in raw_lines:
                    identity = (str(s.get('RB','')),str(s.get('Art_ID','')),str(s.get('Iznos','')),
                                str(s.get('Kolicina','')),str(s.get('BKod_ID','')))
                    lines[identity] = s
                if not lines:
                    bad.append('missing lines: '+str(key));continue
                f=m=0.
                for s in lines.values():
                    v=float(s.get('Iznos') or 0)
                    if not math.isfinite(v): raise ValueError('Invalid amount: '+day)
                    if str(s.get('Art_ID','')).strip() in fuel: f+=v
                    else: m+=v
                total=f+m
                ztotal=float(z.get('Iznos') or 0)
                if total<=0 or abs(total-ztotal)>max(0.05,abs(ztotal)*0.002):
                    bad.append('receipt total mismatch: '+str(key));continue
                cash=float(z.get('Gotovina') or 0)-float(z.get('Povracaj') or 0)
                if not math.isfinite(cash) or cash < -0.01:
                    bad.append('invalid cash: '+str(key));continue
                net_cash+=cash
                sums['fuel_sales']+=f; sums['market_sales']+=m
                sums['cash_fuel']+=cash*f/total
                sums['cash_market']+=cash*m/total
            archived=c.execute('SELECT gotovina,povracaj FROM cash_daily WHERE day=?',(day,)).fetchone()
            if archived is None: bad.append('cash_daily missing')
            elif abs(net_cash-(float(archived[0] or 0)-float(archived[1] or 0)))>0.05:
                bad.append('cash_daily does not match receipts')
            if bad:
                # Never replace with invented amounts or mark an invalid day verified.
                c.execute('UPDATE kasa_group_daily SET verified=0,detail=?,updated_at=CURRENT_TIMESTAMP WHERE day=?',
                          (json.dumps({'split_verified':False,'audit_errors':bad[:10]},ensure_ascii=False),day))
                continue
            sums={k:round(v,2) for k,v in sums.items()}
            # Force the two split figures to add to the authoritative receipt cash.
            authoritative=round(net_cash,2)
            sums['cash_market']=round(authoritative-sums['cash_fuel'],2)
            detail=dict(sums,split_verified=True,sales_verified=True,excluded_reklamacija=True,
                        receipt_count=len(group),audited_from='archived_receipt_lines')
            old=c.execute('SELECT fuel_sales,market_sales,cash_fuel,cash_market,verified FROM kasa_group_daily WHERE day=?',(day,)).fetchone()
            new=tuple(sums[k] for k in ('fuel_sales','market_sales','cash_fuel','cash_market'))+(1,)
            if old and all(a is not None and abs(float(a)-float(b))<0.005 for a,b in zip(old,new)):
                continue
            c.execute("""INSERT INTO kasa_group_daily(day,fuel_sales,market_sales,cash_fuel,cash_market,verified,detail)
              VALUES(?,?,?,?,?,?,?) ON CONFLICT(day) DO UPDATE SET
              fuel_sales=excluded.fuel_sales,market_sales=excluded.market_sales,
              cash_fuel=excluded.cash_fuel,cash_market=excluded.cash_market,
              verified=excluded.verified,detail=excluded.detail,updated_at=CURRENT_TIMESTAMP""",
              (day,*new,json.dumps(detail,ensure_ascii=False)))
            changed+=1
        return changed
