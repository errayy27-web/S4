@echo off
cd /d "%~dp0"
py -3 -m pip install -r requirements-build.txt
py -3 -m PyInstaller --noconfirm --clean --onefile --name SSOIL_Server --hidden-import merkez_arsiv --hidden-import ssoil_kasa_ek --hidden-import pyodbc SSOIL_Server.py
if errorlevel 1 (echo EXE derleme basarisiz & pause & exit /b 1)
echo EXE hazir: dist\SSOIL_Server.exe
pause
