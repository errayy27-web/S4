"""SS OIL PC Merkezi. Own SQLite database only; source databases SELECT only."""
import os, json, sqlite3, threading, time, secrets, datetime, traceback, math, shutil, sys
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
from pathlib import Path
import vardiya_entegre

ROOT=Path(sys.executable).resolve().parent if getattr(sys,"frozen",False) else Path(__file__).resolve().parent
DATA=ROOT/'veriler'; DATA.mkdir(exist_ok=True)
DB=DATA/'ssoil_merkez.sqlite3'
CONFIG=ROOT/'ayarlar.json'
if not CONFIG.exists():
    CONFIG.write_text(json.dumps({'port':8767,'listen':'0.0.0.0','token':secrets.token_urlsafe(32),'poll_seconds':3,'odbc_connection':'','mtel_db':r'\\192.168.100.50\Local2\Local.db3','aero_db':r'\\192.168.100.50\Local\Local.db3'},indent=2),encoding='utf-8')
CFG=json.loads(CONFIG.read_text(encoding='utf-8'))
LOCK=threading.RLock()
def conn():
    c=sqlite3.connect(str(DB),timeout=20)
    c.row_factory=sqlite3.Row
    c.execute('PRAGMA journal_mode=WAL')
    c.execute('PRAGMA busy_timeout=20000')
    return c

def setup():
    with conn() as c:
        # Earlier releases used a different Dopuna schema. Preserve that table
        # untouched under a legacy name rather than dropping historical data.
        existing = c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='dopuna_transactions'").fetchone()
        if existing:
            columns = {row[1] for row in c.execute('PRAGMA table_info(dopuna_transactions)')}
            required = {'source', 'source_id', 'tx_date', 'tx_time', 'amount_minor', 'status_id', 'client_tx', 'server_tx', 'imported_at'}
            if not required.issubset(columns):
                suffix = 1
                while c.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", ('dopuna_transactions_legacy_'+str(suffix),)).fetchone():
                    suffix += 1
                c.execute('ALTER TABLE dopuna_transactions RENAME TO dopuna_transactions_legacy_'+str(suffix))
                print('[MIGRATION] Eski Dopuna tablosu korundu: dopuna_transactions_legacy_'+str(suffix))
        c.executescript('''
        CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY AUTOINCREMENT,kind TEXT NOT NULL,entity_id TEXT NOT NULL,actor TEXT NOT NULL,payload TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,request_id TEXT UNIQUE);
        CREATE TABLE IF NOT EXISTS labels(id TEXT PRIMARY KEY,product_id TEXT NOT NULL,barcode TEXT NOT NULL DEFAULT '',quantity INTEGER NOT NULL DEFAULT 1,status TEXT NOT NULL DEFAULT 'pending',updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS orders(id TEXT PRIMARY KEY,body TEXT NOT NULL,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS suppliers(id TEXT PRIMARY KEY,body TEXT NOT NULL,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS stock_counts(id INTEGER PRIMARY KEY AUTOINCREMENT,session_id TEXT NOT NULL,product_id TEXT NOT NULL,area TEXT NOT NULL DEFAULT '',quantity REAL NOT NULL,actor TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,request_id TEXT UNIQUE);
        CREATE TABLE IF NOT EXISTS product_photos(product_id TEXT PRIMARY KEY,photo_ref TEXT NOT NULL,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS stock_tracking(product_id TEXT PRIMARY KEY,source_stock REAL NOT NULL,net_stock REAL NOT NULL,sales_at_anchor REAL NOT NULL,day TEXT NOT NULL,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS stock_change_log(id INTEGER PRIMARY KEY AUTOINCREMENT,product_id TEXT NOT NULL,old_stock REAL,new_stock REAL,old_name TEXT,new_name TEXT,old_price REAL,new_price REAL,old_barcodes TEXT,new_barcodes TEXT,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS cash_daily(day TEXT PRIMARY KEY,gotovina REAL,povracaj REAL,kartica REAL,bonus REAL,regres REAL,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS products_snapshot(product_id TEXT PRIMARY KEY,name TEXT,price REAL,stock REAL,barcodes TEXT NOT NULL DEFAULT '[]',updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS sales_totals(product_id TEXT PRIMARY KEY,quantity REAL NOT NULL,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS sales_receipt_items(day TEXT NOT NULL,broj TEXT NOT NULL,product_id TEXT NOT NULL,quantity REAL NOT NULL,first_seen TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(day,broj,product_id));
        CREATE INDEX IF NOT EXISTS idx_sales_receipt_items_day ON sales_receipt_items(day);
        CREATE TABLE IF NOT EXISTS sales_daily(day TEXT NOT NULL,product_id TEXT NOT NULL,quantity REAL NOT NULL,PRIMARY KEY(day,product_id));
        CREATE TABLE IF NOT EXISTS stock_adjustments(id INTEGER PRIMARY KEY AUTOINCREMENT,session_id TEXT NOT NULL,product_id TEXT NOT NULL,kind TEXT NOT NULL CHECK(kind IN ('eksik','fazla')),quantity REAL NOT NULL CHECK(quantity>=0),note TEXT NOT NULL DEFAULT '',actor TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,request_id TEXT UNIQUE);
        CREATE TABLE IF NOT EXISTS source_status(name TEXT PRIMARY KEY,ok INTEGER NOT NULL,details TEXT NOT NULL,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
        CREATE TABLE IF NOT EXISTS dopuna_transactions(source TEXT NOT NULL,source_id TEXT NOT NULL,tx_date TEXT NOT NULL,tx_time TEXT NOT NULL DEFAULT '',amount_minor INTEGER NOT NULL,status_id TEXT NOT NULL,client_tx TEXT,server_tx TEXT,imported_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(source,source_id));
        CREATE INDEX IF NOT EXISTS ix_dopuna_day ON dopuna_transactions(tx_date,source,status_id);

        CREATE TABLE IF NOT EXISTS shared(section TEXT NOT NULL,item_key TEXT NOT NULL,value_json TEXT,revision INTEGER NOT NULL DEFAULT 0,changed_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(section,item_key));
        CREATE TABLE IF NOT EXISTS shared_changes(revision INTEGER PRIMARY KEY AUTOINCREMENT,event_id TEXT NOT NULL UNIQUE,section TEXT NOT NULL,item_key TEXT NOT NULL,value_json TEXT,changed_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
        ''')

def record(c,kind,entity,actor,payload,request_id):
    c.execute('INSERT INTO events(kind,entity_id,actor,payload,request_id) VALUES(?,?,?,?,?)',(kind,entity,actor,json.dumps(payload,ensure_ascii=False),request_id))

def sql_read(sql,params=()):
    if not CFG.get('odbc_connection'):raise RuntimeError('ODBC henüz ayarlanmadı')
    import pyodbc
    with pyodbc.connect(CFG['odbc_connection'],timeout=8,autocommit=True) as c:
        return c.cursor().execute(sql,params).fetchall()

def update_source(name,ok,details):
    with LOCK,conn() as c:
        c.execute('INSERT INTO source_status(name,ok,details) VALUES(?,?,?) ON CONFLICT(name) DO UPDATE SET ok=excluded.ok,details=excluded.details,updated_at=CURRENT_TIMESTAMP',(name,int(ok),str(details)[:400]))

def _dopuna_day(raw):
    """Normalize PcPos transaction dates without assuming a single display format."""
    if raw is None:
        return None
    if isinstance(raw, (datetime.datetime, datetime.date)):
        return raw.date().isoformat() if isinstance(raw, datetime.datetime) else raw.isoformat()
    value = str(raw).strip()
    # PcPos sometimes adds a dot after the year: 22.10.2026. 08:20:03
    value = __import__("re").sub(r"^(\d{2}\.\d{2}\.\d{4})\.\s+(?=\d{2}:\d{2})", r"\1 ", value)
    if not value:
        return None
    for fmt in (
        '%d.%m.%Y %H:%M:%S.%f', '%d.%m.%Y %H:%M:%S',
        '%d.%m.%Y %H:%M', '%d.%m.%Y',
        '%Y-%m-%d %H:%M:%S.%f', '%Y-%m-%d %H:%M:%S',
        '%Y-%m-%d %H:%M', '%Y-%m-%dT%H:%M:%S.%f',
        '%Y-%m-%dT%H:%M:%S', '%Y-%m-%d',
        '%d/%m/%Y %H:%M:%S', '%d/%m/%Y',
    ):
        try:
            return datetime.datetime.strptime(value, fmt).date().isoformat()
        except ValueError:
            pass
    try:
        return datetime.datetime.fromisoformat(value.replace('Z', '+00:00')).date().isoformat()
    except ValueError:
        return None


def _open_dopuna_readonly(path):
    """Open an existing Dopuna SQLite file without URI UNC authority errors."""
    value = str(path)
    if not os.path.isfile(value):
        raise FileNotFoundError('Dopuna dosyasi bulunamadi: ' + value)
    if os.name == 'nt' and value.startswith('\\\\'):
        # Native UNC path avoids SQLite's invalid uri authority error.
        # Source file must already exist; query_only blocks SQL writes.
        db = sqlite3.connect(value, timeout=8)
    else:
        db = sqlite3.connect(Path(value).resolve().as_uri() + '?mode=ro', uri=True, timeout=8)
    db.row_factory = sqlite3.Row
    db.execute('PRAGMA query_only=ON')
    return db


def import_dopuna(source):
    """Copy successful PcPos top-ups into our own DB; source is read-only."""
    path = CFG.get(source + '_db')
    if not path or not os.path.isfile(path):
        raise RuntimeError(source.upper() + ' Dopuna dosyasina erisilemiyor: ' + str(path))
    imported = 0
    skipped = 0
    with _open_dopuna_readonly(path) as source_db:
        cols = {r[1].lower(): r[1] for r in source_db.execute('PRAGMA table_info("txes")')}
        required = {'date', 'amount', 'statusid'}
        if not required.issubset(cols):
            raise RuntimeError('txes alanlari eksik: ' + ', '.join(sorted(required - set(cols))))
        # Some PcPos versions omit the id column; SQLite rowid is a stable fallback
        # for ordinary rowid tables. Do not use an unstable list position as an ID.
        id_col = cols.get('id')
        select_sql = 'SELECT rowid AS __ssoil_rowid__, * FROM "txes"' if not id_col else 'SELECT * FROM "txes"'
        with LOCK, conn() as target:
            import merkez_arsiv
            merkez_arsiv.initialize(target)
            for r in source_db.execute(select_sql):
                row = dict(r)
                raw_status = row.get(cols['statusid'])
                status = str(raw_status if raw_status is not None else '').strip().strip('()').strip()
                if status not in ('00', '0'):
                    continue
                day = _dopuna_day(row.get(cols['date']))
                try:
                    amount = row.get(cols['amount'])
                    minor = int(str(amount).strip())
                except (TypeError, ValueError):
                    skipped += 1
                    continue
                raw_id = row.get(id_col) if id_col else row.get('__ssoil_rowid__')
                if day is None or raw_id is None or minor < 0:
                    skipped += 1
                    continue
                source_id = str(raw_id)
                target.execute('''INSERT INTO dopuna_transactions(source,source_id,tx_date,tx_time,amount_minor,status_id,client_tx,server_tx)
                    VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(source,source_id) DO UPDATE SET
                    tx_date=excluded.tx_date,tx_time=excluded.tx_time,amount_minor=excluded.amount_minor,
                    status_id=excluded.status_id,client_tx=excluded.client_tx,server_tx=excluded.server_tx''',
                    (source, source_id, day, str(row.get(cols['date'])), minor, status,
                     str(row.get('clientTx')) if row.get('clientTx') is not None else None,
                     str(row.get('serverTx')) if row.get('serverTx') is not None else None))
                archive = 'MERKEZ_MTEL_DOPUNA' if source == 'mtel' else 'MERKEZ_AERO_DOPUNA'
                target.execute('INSERT INTO ' + archive + '''(islem_id,tarih,tutar,veri) VALUES(?,?,?,?)
                    ON CONFLICT(islem_id) DO UPDATE SET tarih=excluded.tarih,tutar=excluded.tutar,veri=excluded.veri''',
                    (source_id, day, minor / 100, json.dumps(row, ensure_ascii=False, default=str)))
                imported += 1
            merkez_arsiv.update_dopuna_totals(target)
    update_source('dopuna_' + source, True, f'{imported} basarili islem; {skipped} gecersiz')
    return imported


def read_dopuna(path, day):
    """Read archived daily totals, never invent a zero for an unreadable source."""
    source = 'mtel' if str(path) == str(CFG.get('mtel_db')) else 'aero'
    with LOCK, conn() as c:
        table = 'UYG_MTEL_GUNLUK' if source == 'mtel' else 'UYG_AERO_GUNLUK'
        exists = c.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)).fetchone()
        daily = c.execute('SELECT toplam_tutar,islem_sayisi FROM ' + table + ' WHERE tarih=?', (day,)).fetchone() if exists else None
        state = c.execute('SELECT ok,details,updated_at FROM source_status WHERE name=?', ('dopuna_' + source,)).fetchone()
    verified = bool(state and state['ok'])
    amount = round(float(daily[0]), 2) if daily else (0.0 if verified else None)
    count = int(daily[1]) if daily else (0 if verified else None)
    return {'amount': amount, 'transactions': count, 'verified': verified,
            'source': 'ssoil_merkez.sqlite3', 'last_sync': state['updated_at'] if state else None,
            'warning': None if verified else (str(state['details']) if state else 'Ilk Dopuna aktarimi yapilmadi')}


def import_dopuna_incremental(source):
    # Recheck today's and yesterday's successful top-ups, plus all new IDs.

    # Source SQLite is SELECT-only. Central archive is keyed by source transaction ID.
    # Old daily totals are only recalculated when a real record changes.
    path = CFG.get(source + '_db')
    if not path or not os.path.isfile(path):
        raise RuntimeError('Dopuna kaynagi bulunamadi: ' + str(path))
    today = datetime.date.today()
    recent = {today.isoformat(), (today - datetime.timedelta(days=1)).isoformat()}
    with _open_dopuna_readonly(path) as remote:
        columns = {r[1].lower(): r[1] for r in remote.execute('PRAGMA table_info("txes")')}
        if not {'id', 'date', 'amount', 'statusid'}.issubset(columns):
            raise RuntimeError(source + ' txes id/date/amount/statusId alanlari eksik')
        with LOCK, conn() as local:
            local.execute('CREATE TABLE IF NOT EXISTS dopuna_cursor(source TEXT PRIMARY KEY,last_id INTEGER NOT NULL DEFAULT 0)')
            cursor = local.execute('SELECT last_id FROM dopuna_cursor WHERE source=?', (source,)).fetchone()
            last = int(cursor[0]) if cursor else 0
        # Read-only source scan: dates can be text in multiple formats, so
        # filtering on the SQLite date column would silently miss valid rows.
        rows = remote.execute('SELECT * FROM "txes"').fetchall()
        max_id = last
        changed = 0
        touched = set()
        with LOCK, conn() as local:
            import merkez_arsiv
            merkez_arsiv.initialize(local)
            archive = 'MERKEZ_MTEL_DOPUNA' if source == 'mtel' else 'MERKEZ_AERO_DOPUNA'
            daily = 'UYG_MTEL_GUNLUK' if source == 'mtel' else 'UYG_AERO_GUNLUK'
            for record in rows:
                item = dict(record)
                try:
                    rid = int(item[columns['id']])
                except (TypeError, ValueError):
                    continue
                max_id = max(max_id, rid)
                day = _dopuna_day(item.get(columns['date']))
                if rid <= last and day not in recent:
                    continue
                status = str(item.get(columns['statusid']) or '').strip().strip('()').strip()
                if status not in ('00', '0'):
                    continue
                try:
                    minor = int(str(item.get(columns['amount'])).strip())
                except (TypeError, ValueError):
                    continue
                if not day or minor < 0:
                    continue
                sid = str(rid)
                old = local.execute('SELECT tarih,tutar FROM ' + archive + ' WHERE islem_id=?', (sid,)).fetchone()
                if old and old[0] == day and abs(float(old[1]) - minor / 100.0) < 0.00001:
                    continue
                local.execute('''INSERT INTO dopuna_transactions(source,source_id,tx_date,tx_time,amount_minor,status_id,client_tx,server_tx)
                    VALUES(?,?,?,?,?,?,?,?) ON CONFLICT(source,source_id) DO UPDATE SET
                    tx_date=excluded.tx_date,tx_time=excluded.tx_time,amount_minor=excluded.amount_minor,
                    status_id=excluded.status_id,client_tx=excluded.client_tx,server_tx=excluded.server_tx''',
                    (source, sid, day, str(item.get(columns['date'])), minor, status,
                     str(item.get(columns.get('clienttx'))) if item.get(columns.get('clienttx')) is not None else None,
                     str(item.get(columns.get('servertx'))) if item.get(columns.get('servertx')) is not None else None))
                local.execute('INSERT INTO ' + archive + '''(islem_id,tarih,tutar,veri) VALUES(?,?,?,?)
                    ON CONFLICT(islem_id) DO UPDATE SET tarih=excluded.tarih,tutar=excluded.tutar,veri=excluded.veri''',
                    (sid, day, minor / 100.0, json.dumps(item, ensure_ascii=False, default=str)))
                if old:
                    touched.add(old[0])
                touched.add(day)
                changed += 1
            for day in touched:
                total, count = local.execute('SELECT COALESCE(ROUND(SUM(tutar),2),0),COUNT(*) FROM ' + archive + ' WHERE tarih=?', (day,)).fetchone()
                local.execute('INSERT INTO ' + daily + '''(tarih,toplam_tutar,islem_sayisi) VALUES(?,?,?)
                    ON CONFLICT(tarih) DO UPDATE SET toplam_tutar=excluded.toplam_tutar,
                    islem_sayisi=excluded.islem_sayisi,updated_at=CURRENT_TIMESTAMP''', (day, total, count))
            local.execute('INSERT INTO dopuna_cursor(source,last_id) VALUES(?,?) ON CONFLICT(source) DO UPDATE SET last_id=excluded.last_id', (source, max_id))
    update_source('dopuna_' + source, True, str(changed) + ' yeni/duzeltilen islem; bugun ve dun kontrol edildi')
    return changed


def poll_dopuna():
    for source in ('mtel', 'aero'):
        try:
            import_dopuna_incremental(source)
        except Exception as e:
            update_source('dopuna_' + source, False, str(e)[:400])

def validate_reklamacija_today(day):
    end=(datetime.date.fromisoformat(day)+datetime.timedelta(days=1)).isoformat()
    unknown=sql_read("SELECT TOP 1 CAST(Reklamacija AS NVARCHAR(100)) FROM dbo.SmP_Z WHERE DatumE>=? AND DatumE<? AND Reklamacija IS NOT NULL AND LTRIM(RTRIM(CAST(Reklamacija AS NVARCHAR(100)))) NOT IN ('','*')",(day,end))
    if unknown:
        raise RuntimeError('Bilinmeyen Reklamacija degeri: '+str(unknown[0][0]))

def cash_today(day):
    # SmP_Z is the ONLY source for cash/card/refunds. Never sum receipts twice.
    validate_reklamacija_today(day)
    sql="""SELECT COALESCE(SUM(CAST(Gotovina AS float)),0), COALESCE(SUM(CAST(Povracaj AS float)),0), COALESCE(SUM(CAST(Kartica AS float)),0) FROM dbo.SmP_Z WHERE DatumE >= ? AND DatumE < ? AND (Reklamacija IS NULL OR LTRIM(RTRIM(CAST(Reklamacija AS NVARCHAR(100)))) = '')"""
    end=(datetime.date.fromisoformat(day)+datetime.timedelta(days=1)).isoformat()
    r=sql_read(sql,(day,end))[0]
    return {'gotovina':round(float(r[0] or 0),2),'povracaj':round(float(r[1] or 0),2),'kartica':round(float(r[2] or 0),2)}

def finance_today():
    day=datetime.date.today().isoformat()
    out={'day':day,'server_time':datetime.datetime.now().isoformat(timespec='seconds')}
    errors={}
    try:cash=cash_today(day)
    except Exception as e:cash=None;errors['sql']=str(e)[:250]
    dops={}
    for key in ('mtel','aero'):
        try:dops[key]=read_dopuna(CFG.get(key+'_db'),day)
        except Exception as e:dops[key]={'verified':False,'amount':None,'error':str(e)[:200]};errors[key]=str(e)[:200]
    out['dopuna']=dops
    if cash is not None:
        out['kartica']=cash['kartica']
        out['nakit_pos']=round(cash['gotovina']-cash['povracaj'],2)
        out['nakit']=round(out['nakit_pos']+sum(float(dops[k]['amount'] or 0) for k in dops),2)
        out['nakit_complete']=all(dops[k]['verified'] for k in dops)
        out['note']='Povracaj nakitten bir kez dusulur. Dopuna dosyasi okunamiyorsa kesin toplam verilmez.'
    else:out.update({'nakit':None,'kartica':None,'nakit_complete':False})
    if errors:out['errors']=errors
    return out

def fuel_data():
    # Fuel IDs must be explicitly confirmed. No fabricated liters or product mapping.
    mapping=CFG.get('fuel_art_ids',{})
    if not mapping:return {'verified':False,'items':[],'reason':'fuel_art_ids ayarlanmadi; yakit gruplari tahmin edilmez'}
    ids={str(x) for values in mapping.values() for x in values}
    with LOCK,conn() as c:
        rows={r['product_id']:dict(r) for r in c.execute('SELECT p.product_id,p.name,COALESCE(t.net_stock,p.stock) AS stock,p.price,p.updated_at FROM products_snapshot p LEFT JOIN stock_tracking t ON t.product_id=p.product_id') if r['product_id'] in ids}
    return {'verified':all(pid in rows for pid in ids),'items':[{'group':name,'products':[rows.get(str(pid)) for pid in pids]} for name,pids in mapping.items()],'note':'ART Kolicina guncel kaynak stogudur; tekrar satis dusulmez.'}

def valid_sales_today(day):
    """Read only valid, dated receipt lines; never multiply joined receipt lines."""
    end=(datetime.date.fromisoformat(day)+datetime.timedelta(days=1)).isoformat()
    s_cols={str(r[0]).lower() for r in sql_read("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='SmP_S'")}
    z_cols={str(r[0]).lower() for r in sql_read("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA='dbo' AND TABLE_NAME='SmP_Z'")}
    if not {'broj','art_id','kolicina'}.issubset(s_cols) or not {'broj','datume','reklamacija'}.issubset(z_cols):
        raise RuntimeError('SmP_S / SmP_Z fiş eşleştirme sütunları eksik; stok değiştirilmedi')
    join='z.Broj=s.Broj'
    if 'kasa_id' in s_cols and 'kasa_id' in z_cols:
        join+=' AND z.Kasa_ID=s.Kasa_ID'
    else:
        repeated=sql_read('SELECT TOP 1 Broj FROM dbo.SmP_Z GROUP BY Broj HAVING COUNT(DISTINCT CONVERT(date,DatumE))>1')
        if repeated:
            raise RuntimeError('Broj farklı günlerde tekrarlanıyor ve Kasa_ID eşleştirmesi yok; stok değiştirilmedi')
    # Never count unknown reklamacija markers as sales. Verify the source convention.
    invalid=sql_read("SELECT TOP 1 CAST(Reklamacija AS NVARCHAR(100)) FROM dbo.SmP_Z WHERE DatumE>=? AND DatumE<? AND Reklamacija IS NOT NULL AND LTRIM(RTRIM(CAST(Reklamacija AS NVARCHAR(100)))) NOT IN ('','*')",(day,end))
    if invalid:
        raise RuntimeError('Bilinmeyen Reklamacija degeri; satis guncellenmedi: '+str(invalid[0][0]))
    # A repeated Broj across different registers would collapse receipt keys in local cache.
    if 'kasa_id' in s_cols and 'kasa_id' in z_cols:
        collision=sql_read('SELECT TOP 1 Broj FROM dbo.SmP_Z WHERE DatumE>=? AND DatumE<? GROUP BY Broj HAVING COUNT(DISTINCT Kasa_ID)>1',(day,end))
        if collision:
            raise RuntimeError('Ayni Broj birden fazla Kasa_ID ile kullanilmis; satis birlestirilmedi')
    valid="(z.Reklamacija IS NULL OR LTRIM(RTRIM(CAST(z.Reklamacija AS NVARCHAR(100)))) = '')"
    sql=("SELECT s.Broj,s.Art_ID,SUM(CAST(s.Kolicina AS float)) FROM dbo.SmP_S s "
         "WHERE s.Broj IS NOT NULL AND EXISTS (SELECT 1 FROM dbo.SmP_Z z WHERE "
         +join+" AND z.DatumE>=? AND z.DatumE<? AND "+valid+") "
         "GROUP BY s.Broj,s.Art_ID")
    return sql_read(sql,(day,end))

def poll_once():
    # Separate source SQL is never modified. A failed poll does not destroy prior snapshots.
    if not CFG.get('odbc_connection'):return
    try:
        products=sql_read('SELECT Art_ID,Naziv,PCena,Kolicina FROM dbo.ART')
        barcodes=sql_read('SELECT Art_ID,BKod_ID FROM dbo.ART_BK')
        # A receipt (Broj) can contain several products and repeated lines of one product.
        # Group by BOTH receipt and product, not by receipt alone.
        today=datetime.date.today().isoformat()
        sales=valid_sales_today(today)
        codes={}
        for aid,barcode in barcodes:
            if barcode is not None:codes.setdefault(str(aid),set()).add(str(barcode))
        with LOCK,conn() as c:
            # Rebuild only today's live receipt ledger from SQL on every poll.
            # This removes receipts cancelled hours after their original sale.
            # Historical days are not touched.
            c.execute('DELETE FROM sales_receipt_items WHERE day=?',(today,))
            for broj,aid,qty in sales:
                if aid is None:continue
                quantity=float(qty or 0)
                if not math.isfinite(quantity):continue
                c.execute('INSERT INTO sales_receipt_items(day,broj,product_id,quantity) VALUES(?,?,?,?)',
                          (today,str(broj),str(aid),quantity))
            # Sales_daily previously used a delta method. Replace TODAY with the
            # authoritative ledger to avoid mixing incompatible counting schemes.
            c.execute('DELETE FROM sales_daily WHERE day=?',(today,))
            c.execute("""INSERT INTO sales_daily(day,product_id,quantity)
                         SELECT day,product_id,SUM(quantity) FROM sales_receipt_items
                         WHERE day=? GROUP BY day,product_id""",(today,))
            # Keep /sales compatibility with the phone's existing API.
            c.execute('UPDATE sales_totals SET quantity=0,updated_at=CURRENT_TIMESTAMP')
            for row in c.execute('SELECT product_id,SUM(quantity) AS quantity FROM sales_receipt_items WHERE day=? GROUP BY product_id',(today,)).fetchall():
                c.execute('INSERT INTO sales_totals(product_id,quantity) VALUES(?,?) ON CONFLICT(product_id) DO UPDATE SET quantity=excluded.quantity,updated_at=CURRENT_TIMESTAMP',(row['product_id'],row['quantity']))
            # Store ART source values separately from the phone-facing net stock.
            # On first observation, anchor against sales already present today.
            # If ART itself decreases by the new sales amount, don't subtract twice.
            # If ART increases (goods received), apply the increase immediately.
            current_sales={str(r['product_id']):float(r['quantity']) for r in c.execute('SELECT product_id,SUM(quantity) AS quantity FROM sales_receipt_items WHERE day=? GROUP BY product_id',(today,))}
            for aid,name,price,stock in products:
                pid=str(aid); source_qty=float(stock or 0); current_qty=current_sales.get(pid,0.0)
                old=c.execute('SELECT name,price,stock,barcodes FROM products_snapshot WHERE product_id=?',(pid,)).fetchone()
                new_codes=json.dumps(sorted(codes.get(pid,[])))
                if old and (old['name']!=str(name or '') or float(old['price'] or 0)!=float(price or 0) or float(old['stock'] or 0)!=source_qty or old['barcodes']!=new_codes):
                    c.execute('INSERT INTO stock_change_log(product_id,old_stock,new_stock,old_name,new_name,old_price,new_price,old_barcodes,new_barcodes) VALUES(?,?,?,?,?,?,?,?,?)',(pid,old['stock'],source_qty,old['name'],str(name or ''),old['price'],float(price or 0),old['barcodes'],new_codes))
                c.execute('INSERT INTO products_snapshot(product_id,name,price,stock,barcodes) VALUES(?,?,?,?,?) ON CONFLICT(product_id) DO UPDATE SET name=excluded.name,price=excluded.price,stock=excluded.stock,barcodes=excluded.barcodes,updated_at=CURRENT_TIMESTAMP',(pid,str(name or ''),float(price or 0),source_qty,new_codes))
                tr=c.execute('SELECT source_stock,net_stock,sales_at_anchor,day FROM stock_tracking WHERE product_id=?',(pid,)).fetchone()
                # Source ART is the last official inventory. Compute live inventory
                # from currently VALID receipt lines, so cancelled receipts restore
                # stock automatically and idempotently.
                if tr is None or tr['day'] != today:
                    net = source_qty - current_qty
                else:
                    prior_sales = float(tr['sales_at_anchor'])
                    prior_source = float(tr['source_stock'])
                    source_delta = source_qty - prior_source
                    sales_delta = current_qty - prior_sales
                    # If ART decreased by the same amount as newly registered sales,
                    # those sales have already been applied at the source.
                    # Otherwise retain the previous reconciliation offset, which
                    # accounts for earlier source-side closures/receipts.
                    prior_offset = float(tr['net_stock']) - (prior_source - prior_sales)
                    if sales_delta > 0 and abs(source_delta + sales_delta) < 0.0001:
                        prior_offset += sales_delta
                    net = source_qty - current_qty + prior_offset
                c.execute('INSERT INTO stock_tracking(product_id,source_stock,net_stock,sales_at_anchor,day) VALUES(?,?,?,?,?) ON CONFLICT(product_id) DO UPDATE SET source_stock=excluded.source_stock,net_stock=excluded.net_stock,sales_at_anchor=excluded.sales_at_anchor,day=excluded.day,updated_at=CURRENT_TIMESTAMP',(pid,source_qty,net,current_qty,today))
            c.execute('INSERT INTO source_status(name,ok,details) VALUES(?,?,?) ON CONFLICT(name) DO UPDATE SET ok=excluded.ok,details=excluded.details,updated_at=CURRENT_TIMESTAMP',('sql',1,f'{len(products)} urun; {len(sales)} fis/urun grubu; Broj takip aktif'))
    except Exception as e:
        with LOCK,conn() as c:
            c.execute('INSERT INTO source_status(name,ok,details) VALUES(?,?,?) ON CONFLICT(name) DO UPDATE SET ok=excluded.ok,details=excluded.details,updated_at=CURRENT_TIMESTAMP',('sql',0,str(e)[:400]))

def sync_phone_stock():
    """Keep legacy APK stock identical to validated PC net stock.

    This changes only our local SQLite cache; source SQL stays SELECT-only.
    """
    with LOCK, conn() as c:
        exists=c.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='TELEFON_URUNLER'").fetchone()
        if not exists:
            return
        c.execute("""UPDATE TELEFON_URUNLER
                     SET stock=(SELECT t.net_stock FROM stock_tracking t WHERE t.product_id=TELEFON_URUNLER.id),
                         updated_at=CURRENT_TIMESTAMP
                     WHERE EXISTS (SELECT 1 FROM stock_tracking t
                                   WHERE t.product_id=TELEFON_URUNLER.id
                                     AND t.net_stock IS NOT NULL
                                     AND ABS(t.net_stock-COALESCE(TELEFON_URUNLER.stock,0))>0.000001)""")

def archive_cash_today():
    day=datetime.date.today().isoformat()
    validate_reklamacija_today(day)
    r=sql_read('SELECT COALESCE(SUM(CAST(Gotovina AS float)),0),COALESCE(SUM(CAST(Povracaj AS float)),0),COALESCE(SUM(CAST(Kartica AS float)),0),COALESCE(SUM(CAST(Bonus AS float)),0),COALESCE(SUM(CAST(Regres AS float)),0) FROM dbo.SmP_Z WHERE DatumE >= ? AND DatumE < ? AND (Reklamacija IS NULL OR LTRIM(RTRIM(CAST(Reklamacija AS NVARCHAR(100)))) = '')',(day,(datetime.date.fromisoformat(day)+datetime.timedelta(days=1)).isoformat()))[0]
    with LOCK,conn() as c:
        c.execute('INSERT INTO cash_daily(day,gotovina,povracaj,kartica,bonus,regres) VALUES(?,?,?,?,?,?) ON CONFLICT(day) DO UPDATE SET gotovina=excluded.gotovina,povracaj=excluded.povracaj,kartica=excluded.kartica,bonus=excluded.bonus,regres=excluded.regres,updated_at=CURRENT_TIMESTAMP',(day,*(float(x or 0) for x in r)))
    update_source('cash_archive',True,'SmP_Z bugunluk toplam kaydedildi')

def poll_kasa_groups():
    import ssoil_kasa_ek
    day=datetime.date.today().isoformat()
    data=ssoil_kasa_ek.calc_groups(conn,CFG,day,True)
    ssoil_kasa_ek.save_group(conn,day,data)

def poll_loop():
    last_group=0.0
    last_archive=0.0
    while True:
        poll_once()
        poll_dopuna()
        if time.monotonic()-last_group>=3:
            try:poll_kasa_groups()
            except Exception as e:update_source('kasa_groups',False,str(e)[:250])
            last_group=time.monotonic()
        try:archive_cash_today()
        except Exception as e:update_source('cash_archive',False,str(e)[:250])
        if time.monotonic()-last_archive>=60 or last_archive==0.0:
            try:
                import merkez_arsiv
                merkez_arsiv.run(conn,CFG)
            except Exception as e:
                update_source('merkez_arsiv',False,str(e)[:350])
            last_archive=time.monotonic()
        try:sync_phone_stock()
        except Exception as e:update_source('phone_stock_sync',False,str(e)[:250])
        time.sleep(3)


# Legacy APK endpoints. They use the same SQLite file and the same SQL snapshots.
SHARED_SECTIONS={'labels','orders','suppliers','supplierOf','minimum','photos','discrepancies','orderUnits','barcodeErrors'}
def legacy_snapshot():
    """Read the authoritative product snapshot; legacy table can be empty.

    Keep the APK's existing {products:[{id,name,price,stock,barcodes}]} contract.
    """
    with LOCK, conn() as c:
        rows=c.execute("""SELECT p.product_id AS id,p.name,p.price,
            COALESCE(t.net_stock,p.stock) AS stock,p.barcodes,p.updated_at
            FROM products_snapshot p
            LEFT JOIN stock_tracking t ON t.product_id=p.product_id
            ORDER BY p.name""").fetchall()
        if not rows:
            ready=c.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='TELEFON_URUNLER'").fetchone()
            if ready:
                rows=c.execute('SELECT id,name,price,stock,barcodes,updated_at FROM TELEFON_URUNLER ORDER BY name').fetchall()
    def codes(raw):
        try:
            v=json.loads(raw or '[]') if isinstance(raw,str) else raw
            return v if isinstance(v,list) else []
        except (TypeError,ValueError):return []
    return {'products':[{'id':r['id'],'name':r['name'],'price':r['price'],
        'stock':r['stock'],'barcodes':codes(r['barcodes'])} for r in rows],
        'updated_at':max((r['updated_at'] for r in rows),default=None)}

def legacy_sales():
    with LOCK,conn() as c:
        rows=c.execute('SELECT product_id,quantity FROM sales_totals').fetchall()
    return {'sales':{r['product_id']:r['quantity'] for r in rows}}

def legacy_daily_sales():
    with LOCK,conn() as c:
        rows=c.execute('SELECT day,product_id,quantity FROM sales_daily WHERE day>=? ORDER BY day',((datetime.date.today()-datetime.timedelta(days=6)).isoformat(),)).fetchall()
    result={}
    for r in rows:result.setdefault(r['day'],{})[r['product_id']]=r['quantity']
    return {'daily':result}

def legacy_kasa(day):
    day=day or datetime.date.today().isoformat()
    datetime.date.fromisoformat(day)
    if day==datetime.date.today().isoformat():
        cash=cash_today(day)
    else:
        with LOCK,conn() as c:
            saved=c.execute('SELECT gotovina,povracaj,kartica FROM cash_daily WHERE day=?',(day,)).fetchone()
        if saved is None:raise RuntimeError('Bu tarihe ait kayit bulunamadi')
        cash=dict(saved)
    d={};errors={}
    for kind in ('mtel','aero'):
        try:
            r=read_dopuna(CFG.get(kind+'_db'),day)
            d[kind]={'total':r['amount'],'count':r['transactions'],'status':'ok' if r['verified'] else 'stale'}
        except Exception as e:
            d[kind]={'total':None,'count':None,'status':'unavailable'}
            errors[kind]=str(e)[:150]
    total=sum(d[k]['total'] for k in d) if all(d[k]['total'] is not None for k in d) else None
    net=round(cash['gotovina']-cash['povracaj'],2)
    import ssoil_kasa_ek
    groups=ssoil_kasa_ek.get_group(conn,day) or {}
    return {'date':day,'cash':round(net+(total or 0),2),
            'cash_smpsz':net,'cash_market':(groups.get('cash_market') if groups.get('cash_market') is not None else 0.0),'cash_fuel':(groups.get('cash_fuel') if groups.get('cash_fuel') is not None else net),'fuel_sales':groups.get('fuel_sales'),'market_sales':groups.get('market_sales'),'card':cash['kartica'],'refund':cash['povracaj'],'cash_complete':total is not None,'cash_split_verified':bool(groups.get('verified')) if groups else False,
            'mtel_dopuna':d['mtel']['total'],'aero_dopuna':d['aero']['total'],
            'dopuna':{'date':day,'mtel':d['mtel'],'aero':d['aero'],'total':total},'errors':errors}

def shared_state():
    """PC-authoritative current state, not an event log."""
    with LOCK,conn() as c:
        rows=c.execute('SELECT section,item_key,value_json FROM shared').fetchall()
        revision=c.execute('SELECT COALESCE(MAX(revision),0) FROM shared_changes').fetchone()[0]
    state={section:{} for section in SHARED_SECTIONS}
    for row in rows:
        if row['section'] in state and row['value_json'] is not None:
            state[row['section']][row['item_key']]=json.loads(row['value_json'])
    return {'revision':revision,'state':state}

def shared_get(since):
    with LOCK,conn() as c:
        rows=c.execute('SELECT revision,section,item_key,value_json FROM shared_changes WHERE revision>? ORDER BY revision LIMIT 2000',(since,)).fetchall()
        latest=c.execute('SELECT COALESCE(MAX(revision),0) FROM shared_changes').fetchone()[0]
    return {'revision':latest,'changes':[{'revision':r['revision'],'section':r['section'],'key':r['item_key'],'value':json.loads(r['value_json']) if r['value_json'] is not None else None} for r in rows], 'has_more':bool(rows and rows[-1]['revision']<latest)}

def shared_post(d):
    section=d.get('section');key=str(d.get('key',''));event=str(d.get('event_id',''))
    if section not in SHARED_SECTIONS or not key or len(key)>200 or len(event)<8 or len(event)>200:
        raise ValueError('invalid_shared_event')
    value=d.get('value');encoded=None if value is None else json.dumps(value,ensure_ascii=False)
    with LOCK,conn() as c:
        prev=c.execute('SELECT revision FROM shared_changes WHERE event_id=?',(event,)).fetchone()
        if prev:return {'revision':prev['revision'],'duplicate':True}
        cursor=c.execute('INSERT INTO shared_changes(event_id,section,item_key,value_json) VALUES(?,?,?,?)',(event,section,key,encoded))
        rev=cursor.lastrowid
        if value is None:
            c.execute('DELETE FROM shared WHERE section=? AND item_key=?',(section,key))
        else:
            c.execute('INSERT INTO shared(section,item_key,value_json,revision) VALUES(?,?,?,?) ON CONFLICT(section,item_key) DO UPDATE SET value_json=excluded.value_json,revision=excluded.revision,changed_at=CURRENT_TIMESTAMP',(section,key,encoded,rev))
    return {'revision':rev,'duplicate':False}

class API(BaseHTTPRequestHandler):
    def log_message(self,format,*args):print('[HTTP]',format%args)
    def respond(self,status,data):
        raw=json.dumps(data,ensure_ascii=False,default=str).encode('utf-8')
        self.send_response(status);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Content-Length',str(len(raw)));self.send_header('Cache-Control','no-store');self.end_headers();self.wfile.write(raw)
    def authorized(self):
        supplied=self.headers.get('X-SSOIL-Token','') or self.headers.get('X-API-Token','')
        allowed=[str(CFG.get('token','')),str(CFG.get('phone_token',''))]
        return bool(supplied) and any(secrets.compare_digest(supplied,t) for t in allowed if t)
    def handle_request(self):
        u=urlparse(self.path); path=u.path; qs=parse_qs(u.query)
        # Health is a non-sensitive liveness check; other endpoints remain token-protected.
        if self.command=='GET' and path=='/health':
            return self.respond(200,{'status':'ok','server_time':datetime.datetime.now().isoformat(timespec='seconds'),'cloud_connected':False})
        if urlparse(self.path).path=='/health':return self.respond(200,{'status':'ok','server_time':datetime.datetime.now().isoformat(timespec='seconds'),'cloud_connected':False})
        if not self.authorized():return self.respond(401,{'error':'unauthorized'})
        if path.startswith('/vardiya/'):
            return vardiya_entegre.handle(self,path,qs,conn,LOCK)
        if self.command=='GET':
            with LOCK,conn() as c:
                if path=='/health':return self.respond(200,{'status':'ok','server_time':datetime.datetime.now().isoformat(timespec='seconds'),'cloud_connected':False})
                if path=='/snapshot':
                    if qs.get('refresh',['0'])[0] in ('1','true','yes'):poll_once()
                    return self.respond(200,legacy_snapshot())
                if path=='/sales':return self.respond(200,legacy_sales())
                if path=='/daily-sales':return self.respond(200,legacy_daily_sales())
                if path=='/shared-state':return self.respond(200,shared_state())
                if path=='/shared':
                    try:since=max(0,int(qs.get('since',['0'])[0]))
                    except ValueError:return self.respond(400,{'error':'invalid_since'})
                    return self.respond(200,shared_get(since))
                if path=='/kasa':
                    try:return self.respond(200,legacy_kasa(qs.get('date',[None])[0]))
                    except ValueError:return self.respond(400,{'error':'invalid_date'})
                    except Exception as e:return self.respond(503,{'error':'kasa_unavailable','detail':str(e)[:200]})
                if path=='/history-day':
                    day=qs.get('date',[''])[0]
                    try:datetime.date.fromisoformat(day)
                    except ValueError:return self.respond(400,{'error':'invalid_date'})
                    closed=c.execute('SELECT 1 FROM ssoil_closed_days WHERE day=?',(day,)).fetchone() if c.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='ssoil_closed_days'").fetchone() else None
                    z=[{'broj':r['Broj'],'data':json.loads(r['_data'])} for r in c.execute('SELECT Broj,_data FROM MERKEZ_SMP_Z WHERE Tarih=? ORDER BY _key',(day,))]
                    lines=[{'broj':r['Broj'],'data':json.loads(r['_data'])} for r in c.execute('SELECT Broj,_data FROM MERKEZ_SMP_S WHERE Tarih=? ORDER BY _key',(day,))]
                    return self.respond(200,{'date':day,'closed':bool(closed),'pr_z':z,'pr_s':lines})
                if path=='/finance':return self.respond(200,finance_today())
                if path=='/dopuna':
                    day=qs.get('date',[datetime.date.today().isoformat()])[0]
                    try:datetime.date.fromisoformat(day)
                    except ValueError:return self.respond(400,{'error':'invalid_date'})
                    result={}
                    for kind in ('mtel','aero'):
                        try:result[kind]=read_dopuna(CFG.get(kind+'_db'),day)
                        except Exception as e:result[kind]={'verified':False,'error':str(e)[:180]}
                    return self.respond(200,{'date':day,**result})
                if path=='/fuel':return self.respond(200,fuel_data())
                if path=='/status':return self.respond(200,{'sources':[dict(x) for x in c.execute('SELECT * FROM source_status')],'cloud_connected':False})
                if path=='/products':return self.respond(200,{'items':[dict(x)|{'barcodes':json.loads(x['barcodes'])} for x in c.execute('SELECT p.product_id,p.name,p.price,COALESCE(t.net_stock,p.stock) AS stock,p.barcodes,p.updated_at FROM products_snapshot p LEFT JOIN stock_tracking t ON t.product_id=p.product_id ORDER BY p.name LIMIT 20000')]})
                if path=='/events':
                    since=max(0,int(qs.get('since',['0'])[0]));return self.respond(200,{'events':[dict(x)|{'payload':json.loads(x['payload'])} for x in c.execute('SELECT * FROM events WHERE id>? ORDER BY id LIMIT 1000',(since,))]})
                if path=='/discrepancies':
                    sid=qs.get('session_id',[''])[0]
                    if not sid:return self.respond(400,{'error':'session_id_required'})
                    return self.respond(200,{'items':[dict(x) for x in c.execute('SELECT * FROM stock_adjustments WHERE session_id=? ORDER BY id',(sid,))]})
                if path=='/count-summary':
                    sid=qs.get('session_id',[''])[0]
                    if not sid:return self.respond(400,{'error':'session_id_required'})
                    return self.respond(200,{'items':[dict(x) for x in c.execute('SELECT sc.product_id,ps.name,ps.stock AS system_stock,SUM(sc.quantity) AS counted,SUM(sc.quantity)-ps.stock AS difference FROM stock_counts sc LEFT JOIN products_snapshot ps ON ps.product_id=sc.product_id WHERE sc.session_id=? GROUP BY sc.product_id,ps.name,ps.stock ORDER BY sc.product_id',(sid,))]})
                if path=='/counts':
                    sid=qs.get('session_id',[''])[0]
                    if not sid:return self.respond(400,{'error':'session_id_required'})
                    return self.respond(200,{'items':[dict(x) for x in c.execute('SELECT * FROM stock_counts WHERE session_id=? ORDER BY id',(sid,))]})
                if path=='/top':
                    cutoff=(datetime.date.today()-datetime.timedelta(days=6)).isoformat()
                    return self.respond(200,{'items':[dict(x) for x in c.execute('SELECT product_id,SUM(quantity) AS quantity FROM sales_daily WHERE day>=? GROUP BY product_id ORDER BY quantity DESC LIMIT 100',(cutoff,))],'note':'Yalnızca PC izleme başladıktan sonraki satış farkları; yakıt grupları henüz doğrulanmadığı için hariç tutulmadı'})
                if path in ('/labels','/orders','/suppliers','/photos'):
                    table={'/labels':'labels','/orders':'orders','/suppliers':'suppliers','/photos':'product_photos'}[path]
                    return self.respond(200,{'items':[dict(x) for x in c.execute('SELECT * FROM '+table)]})
            return self.respond(404,{'error':'not_found'})
        if self.command=='POST':
            n=int(self.headers.get('Content-Length','0'))
            if n>100000:return self.respond(413,{'error':'too_large'})
            try:d=json.loads(self.rfile.read(n)); assert isinstance(d,dict)
            except Exception:return self.respond(400,{'error':'invalid_json'})
            actor=str(d.get('actor','')).strip(); rid=str(d.get('request_id','')).strip()
            if path=='/shared':
                try:return self.respond(200,shared_post(d))
                except (ValueError,TypeError) as e:return self.respond(400,{'error':str(e)})
                except sqlite3.Error:return self.respond(500,{'error':'database_error'})
            if not actor or not rid or len(rid)>128:return self.respond(400,{'error':'actor_and_request_id_required'})
            if path not in ('/counts','/labels','/orders','/suppliers','/photos','/discrepancies'):return self.respond(404,{'error':'not_found'})
            try:
                with LOCK,conn() as c:
                    if c.execute('SELECT id FROM events WHERE request_id=?',(rid,)).fetchone():return self.respond(200,{'ok':True,'duplicate':True})
                    if path=='/discrepancies':
                        sid=str(d['session_id']);pid=str(d['product_id']);kind=str(d['kind']).lower();qty=float(d['quantity']);note=str(d.get('note',''))
                        if kind not in ('eksik','fazla') or not math.isfinite(qty) or qty<0:return self.respond(400,{'error':'invalid_discrepancy'})
                        c.execute('INSERT INTO stock_adjustments(session_id,product_id,kind,quantity,note,actor,request_id) VALUES(?,?,?,?,?,?,?)',(sid,pid,kind,qty,note,actor,rid));entity=sid
                    elif path=='/counts':
                        sid=str(d['session_id']);pid=str(d['product_id']);qty=float(d['quantity']);area=str(d.get('area',''))
                        if not sid or not pid or not math.isfinite(qty) or abs(qty)>1e9:return self.respond(400,{'error':'invalid_count'})
                        c.execute('INSERT INTO stock_counts(session_id,product_id,area,quantity,actor,request_id) VALUES(?,?,?,?,?,?)',(sid,pid,area,qty,actor,rid));entity=sid
                    elif path=='/labels':
                        entity=str(d['id']);pid=str(d['product_id']);barcode=str(d.get('barcode',''));qty=int(d.get('quantity',1));status=str(d.get('status','pending'))
                        if qty<1 or qty>10000:return self.respond(400,{'error':'invalid_quantity'})
                        c.execute('INSERT INTO labels(id,product_id,barcode,quantity,status) VALUES(?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET product_id=excluded.product_id,barcode=excluded.barcode,quantity=excluded.quantity,status=excluded.status,updated_at=CURRENT_TIMESTAMP',(entity,pid,barcode,qty,status))
                    elif path in ('/orders','/suppliers'):
                        entity=str(d['id']);table=path[1:]
                        c.execute('INSERT INTO '+table+'(id,body) VALUES(?,?) ON CONFLICT(id) DO UPDATE SET body=excluded.body,updated_at=CURRENT_TIMESTAMP',(entity,json.dumps(d.get('body',{}),ensure_ascii=False)))
                    else:
                        entity=str(d['product_id']);ref=str(d['photo_ref'])
                        c.execute('INSERT INTO product_photos(product_id,photo_ref) VALUES(?,?) ON CONFLICT(product_id) DO UPDATE SET photo_ref=excluded.photo_ref,updated_at=CURRENT_TIMESTAMP',(entity,ref))
                    record(c,path[1:],entity,actor,d,rid)
                return self.respond(200,{'ok':True,'duplicate':False})
            except (KeyError,ValueError,TypeError) as e:return self.respond(400,{'error':'invalid_payload','detail':str(e)})
            except sqlite3.Error as e:return self.respond(500,{'error':'database_error','detail':str(e)})
    def do_GET(self):self.handle_request()
    def do_POST(self):self.handle_request()
    def do_PATCH(self):self.handle_request()

if __name__=='__main__':
    setup();vardiya_entegre.init(conn);threading.Thread(target=poll_loop,daemon=True).start()
    threading.Thread(target=vardiya_entegre.loop,args=(conn,LOCK),daemon=True).start()
    host=CFG.get('listen','127.0.0.1');port=int(CFG.get('port',8767))
    print('SS OIL Merkezi hazır:',host,port,'| Veri:',DB,flush=True)
    print('Token ayarlar.json dosyasında. Bu dosyayı paylaşmayın.',flush=True)
    ThreadingHTTPServer((host,port),API).serve_forever()
