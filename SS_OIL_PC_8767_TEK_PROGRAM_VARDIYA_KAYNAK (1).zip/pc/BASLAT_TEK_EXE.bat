@echo off
cd /d "%~dp0"
if exist "kopru_ayarlar.bat" call "kopru_ayarlar.bat"
if exist "SSOIL_Server.exe" (
 "SSOIL_Server.exe"
) else (
 py -3 SSOIL_Server.py
)
pause
